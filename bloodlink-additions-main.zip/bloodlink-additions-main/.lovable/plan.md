
## 1. Import the existing project (no redesign)

The upload is a Vite React SPA with state-driven tab navigation (no `react-router-dom` used) and three context providers (`AuthContext`, `LanguageContext`, `ThemeContext`) persisting to `localStorage`. It plugs cleanly into TanStack Start as a single mounted app — no route migration needed for existing screens.

- Copy the zip's app source into the workspace as-is:
  - `src/components/**` (all existing screens, including all `components/ui/**`)
  - `src/context/**`, `src/hooks/**`, `src/lib/utils.ts`, `src/assets/**`, `public/**` (favicon, gebeya.webp)
- Bring in the zip's `src/index.css` (design tokens + light/dark) and switch `src/styles.css` to import it, so tokens, radii, and dark-mode classes match the original project exactly.
- Install any missing deps from the zip's `package.json` (framer-motion, sonner, next-themes, date-fns, recharts, embla, react-hook-form, zod, etc.) via `bun add`.
- Replace `src/routes/index.tsx` placeholder with a single mount of the existing `App` component (`ThemeProvider > LanguageProvider > AuthProvider > AppContent`). Keep `__root.tsx` intact; update only `<head>` metadata (title "BloodLink AI", description, og).
- Do NOT touch existing screens: Onboarding, Auth, MainLayout, DonorDashboard, HospitalDashboard, BankDashboard, Assistant, RequestsList, NotificationsList, SOSButton, MaternalEmergencyModal — beyond the wiring listed below.

## 2. New persistent profile store

Add `src/context/ProfileContext.tsx` — a single source of truth for user data, persisted to `localStorage` under `bloodlink:profile:v1`, exposed via `useProfile()`. Shape:

- **Personal**: photo, fullName, dob, gender, phone, email, address, state, lga
- **Health**: bloodGroup, genotype, weight, height, medicalConditions[], allergies[], medications[]
- **Availability**: schedule (weekly), emergencyDonation (bool), maxTravelKm
- **Emergency contact**: name, relationship, phone
- **Donation info**: lastDonationDate, nextEligibleDate (derived: last + 56 days if eligible), history[], preferredCentre
- **Eligibility**: latest AI result `{ status: 'eligible'|'screening'|'ineligible', date, recommendation, nextEligibleDate?, reason? }`
- **Settings**: preferredLanguage (mirrors `LanguageContext`), notifications, theme link
- **Appointments**: list of appointments (see §3)

Register `<ProfileProvider>` inside the existing provider tree in `App.tsx` (between Language and Auth) so all screens can consume it without altering layout.

## 3. Appointment booking flow (continuation only)

The current prototype ends at hospital selection. Add new components under `src/components/appointments/` and route them via the existing tab/state pattern (a small local step-state inside DonorDashboard or a new `AppointmentFlow` container mounted when `activeTab === 'booking'`). No changes to existing navigation.

Screens to add:
1. **SelectDate** — calendar (`react-day-picker`, already installed), disables dates < today and dates before `nextEligibleDate` when result is Eligible.
2. **SelectTime** — time slots for chosen date, filtered by hospital availability (mocked list).
3. **AppointmentSummary** — hospital, date/time, type (Donation vs Screening — gated by eligibility, see §6), notes.
4. **AppointmentConfirmation** — success screen with confirmation code, save-to-profile.
5. **AppointmentDetails** — full detail view with actions: **Reschedule**, **Cancel**, **Call hospital** (`tel:`), **Navigate** (`https://maps.google.com/?q=…`).
6. **MyAppointments** — upcoming + history tabs; each item opens AppointmentDetails.

All appointments persist through `ProfileContext.appointments`. Reschedule reuses SelectDate/Time. Cancel confirms via existing shadcn `alert-dialog`.

Add a `nav.appointments` entry in translations and a link in Profile/Dashboard — do not modify MainLayout bottom nav shape.

## 4. Comprehensive Profile section

Refactor the current `Profile.tsx` into a tabbed page (using existing shadcn `tabs`) — do not replace its shell, only expand content:

- Tabs: **Personal**, **Health**, **Availability**, **Emergency Contact**, **Donation**, **Settings**
- Each tab reads/writes through `useProfile()`; edits saved via `react-hook-form` + `zod` validation, then persisted.
- Profile photo uses a file input → base64 in localStorage.
- Donation tab renders lastDonation, nextEligible (derived), history list, preferred centre picker.
- Settings tab adds **Preferred Language** (select: English, Hausa, Yoruba, Igbo, Nigerian Pidgin) — on change calls `setLanguage(...)` from `LanguageContext` AND updates profile; entire app re-renders instantly, and Assistant reads `language` for its replies.

Extend `LanguageContext` translation dictionary with all new keys used by added screens across en/ha/yo/ig/pcm (extend, don't replace — existing keys untouched).

## 5. AI Eligibility Check — single preliminary result

Modify `EligibilityChecker.tsx` (minimal changes, keep questionnaire and existing UI):
- After analysis, show exactly one result card:
  - 🟢 **Eligible** — recommendation + next eligible date (if provided by history)
  - 🟡 **Needs Further Screening** — recommendation to visit a centre
  - 🔴 **Temporarily Ineligible** — reason + next eligible date
- Always show assessment date and disclaimer: *"Preliminary AI assessment. Final eligibility determined by healthcare professionals."*
- Save result to `profile.eligibility` (latest overwrites). Add a "Save & Continue" button.

## 6. Dynamic Dashboard

Update `DonorDashboard.tsx` (edit, don't rewrite) to pull from `useProfile()` instead of placeholders:

- Cards: Blood Group, Genotype, Total Donations, Donation Streak, Last Donation Date, Next Eligible Date, Current Availability, Emergency Donation Status, Upcoming Appointment (next from profile.appointments), Preferred Language.
- **Eligibility Status card** at top — colored per latest result, with **Check Again** button that opens `EligibilityChecker`.
- Empty states: if profile fields missing, show "Complete your profile" CTA linking to Profile tab.

Hospital/Bank dashboards untouched.

## 7. Eligibility-gated appointment booking

In the AppointmentFlow entry (before SelectDate), read `profile.eligibility.status`:
- **eligible** → allow "Blood Donation" and "Health Screening" appointment types.
- **screening** → only "Health Screening" type; disable Donation with tooltip.
- **ineligible** → block booking; show reason + nextEligibleDate + two CTAs: **Set Reminder** (writes a local reminder into profile) and **Chat with BloodLink AI** (switches to `activeTab='assistant'` with a prefilled prompt).

## 8. Profile-aware AI Assistant

Extend `Assistant.tsx` message-handling only (no UI redesign):
- Inject a system-style context object built from `useProfile()` into every request (blood group, genotype, eligibility, last/next donation, availability, appointments).
- Intent handling for offline/local answers (no backend required): "What is my blood group?", "Am I eligible?", "When can I donate again?", "Show my donation history", "What is my availability?" — respond from profile without calling any model.
- Response language follows `LanguageContext.language`.
- If Lovable AI is wired later (out of scope now), the same context object is forwarded server-side.

## 9. Cross-screen synchronization

Because everything flows through `ProfileContext` + `localStorage`, updates in Profile automatically propagate to Dashboard, Assistant, and Appointment flow on next render. Add a small `useEffect` in `ProfileProvider` that broadcasts a `storage` event so other tabs stay in sync.

## 10. Files touched

**New**
- `src/context/ProfileContext.tsx`
- `src/components/appointments/AppointmentFlow.tsx`
- `src/components/appointments/SelectDate.tsx`
- `src/components/appointments/SelectTime.tsx`
- `src/components/appointments/AppointmentSummary.tsx`
- `src/components/appointments/AppointmentConfirmation.tsx`
- `src/components/appointments/AppointmentDetails.tsx`
- `src/components/appointments/MyAppointments.tsx`
- `src/components/profile/PersonalTab.tsx`, `HealthTab.tsx`, `AvailabilityTab.tsx`, `EmergencyContactTab.tsx`, `DonationTab.tsx`, `SettingsTab.tsx`

**Modified (surgical only)**
- `src/App.tsx` — add `<ProfileProvider>` in provider tree
- `src/components/Profile.tsx` — swap body for tabbed layout wiring to new tabs
- `src/components/DonorDashboard.tsx` — replace static values with `useProfile()`, add Eligibility Status card + Check Again
- `src/components/EligibilityChecker.tsx` — single-result rendering + save to profile
- `src/components/Assistant.tsx` — profile-aware intents & language
- `src/context/LanguageContext.tsx` — extend dictionaries with new keys across 5 languages
- `src/routes/__root.tsx` — head metadata for BloodLink AI (title/description/og)
- `src/routes/index.tsx` — mount imported `App`
- `src/styles.css` — import zip's design tokens

**Unchanged**: Onboarding, Auth, MainLayout, SOSButton, MaternalEmergencyModal, RequestsList, NotificationsList, HospitalDashboard, BankDashboard, all `components/ui/*`.

## 11. Verification

After implementation:
- Typecheck via `tsgo`.
- Playwright smoke test in headless Chromium: complete Onboarding → Auth (Donor) → open Profile → fill Personal/Health → run EligibilityChecker → Dashboard reflects data + eligibility card → start booking → SelectDate/Time/Summary/Confirmation → MyAppointments shows entry → switch language in Settings → labels update instantly → Assistant answers "What is my blood group?" from profile.
- Verify dark/light toggle still works and no existing screen visually changes.
