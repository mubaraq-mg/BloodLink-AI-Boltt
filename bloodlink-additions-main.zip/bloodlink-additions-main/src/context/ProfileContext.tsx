import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import type { Language } from './LanguageContext';

export type EligibilityStatus = 'eligible' | 'screening' | 'ineligible';

export interface EligibilityResult {
  status: EligibilityStatus;
  date: string; // ISO
  recommendation: string;
  nextEligibleDate?: string; // ISO
  reason?: string;
}

export interface AppointmentType {
  id: string;
  hospitalId: string;
  hospitalName: string;
  hospitalPhone?: string;
  hospitalAddress?: string;
  date: string; // ISO date (yyyy-mm-dd)
  time: string; // HH:mm
  type: 'donation' | 'screening';
  notes?: string;
  status: 'upcoming' | 'completed' | 'cancelled';
  confirmationCode: string;
  createdAt: string;
}

export interface DonationHistoryEntry {
  id: string;
  date: string;
  centre: string;
  volumeMl?: number;
}

export interface ProfileData {
  personal: {
    photo?: string; // base64
    fullName: string;
    dob: string;
    gender: 'male' | 'female' | 'other' | '';
    phone: string;
    email: string;
    address: string;
    state: string;
    lga: string;
  };
  health: {
    bloodGroup: string;
    genotype: string;
    weight: string;
    height: string;
    medicalConditions: string[];
    allergies: string[];
    medications: string[];
  };
  availability: {
    schedule: Record<string, boolean>; // mon..sun
    emergencyDonation: boolean;
    maxTravelKm: number;
  };
  emergencyContact: {
    name: string;
    relationship: string;
    phone: string;
  };
  donation: {
    lastDonationDate: string;
    history: DonationHistoryEntry[];
    preferredCentre: string;
  };
  eligibility: EligibilityResult | null;
  appointments: AppointmentType[];
  reminders: { id: string; when: string; reason: string }[];
  settings: {
    preferredLanguage: Language;
    notifications: boolean;
  };
}

const STORAGE_KEY = 'bloodlink:profile:v1';

const defaultProfile: ProfileData = {
  personal: {
    photo: undefined,
    fullName: 'Musa Ibrahim',
    dob: '',
    gender: '',
    phone: '',
    email: '',
    address: '',
    state: '',
    lga: '',
  },
  health: {
    bloodGroup: 'O+',
    genotype: 'AA',
    weight: '',
    height: '',
    medicalConditions: [],
    allergies: [],
    medications: [],
  },
  availability: {
    schedule: { mon: true, tue: true, wed: true, thu: true, fri: true, sat: true, sun: false },
    emergencyDonation: true,
    maxTravelKm: 15,
  },
  emergencyContact: { name: '', relationship: '', phone: '' },
  donation: {
    lastDonationDate: '',
    history: [],
    preferredCentre: '',
  },
  eligibility: null,
  appointments: [],
  reminders: [],
  settings: {
    preferredLanguage: 'en',
    notifications: true,
  },
};

interface ProfileContextValue {
  profile: ProfileData;
  setProfile: (updater: (p: ProfileData) => ProfileData) => void;
  updatePersonal: (patch: Partial<ProfileData['personal']>) => void;
  updateHealth: (patch: Partial<ProfileData['health']>) => void;
  updateAvailability: (patch: Partial<ProfileData['availability']>) => void;
  updateEmergencyContact: (patch: Partial<ProfileData['emergencyContact']>) => void;
  updateDonation: (patch: Partial<ProfileData['donation']>) => void;
  updateSettings: (patch: Partial<ProfileData['settings']>) => void;
  saveEligibility: (result: EligibilityResult) => void;
  addAppointment: (appt: AppointmentType) => void;
  updateAppointment: (id: string, patch: Partial<AppointmentType>) => void;
  cancelAppointment: (id: string) => void;
  addReminder: (r: { when: string; reason: string }) => void;
  computedNextEligibleDate: () => string | null;
  totalDonations: number;
  upcomingAppointment: AppointmentType | null;
}

const ProfileContext = createContext<ProfileContextValue | undefined>(undefined);

function loadInitial(): ProfileData {
  if (typeof window === 'undefined') return defaultProfile;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultProfile;
    const parsed = JSON.parse(raw);
    return { ...defaultProfile, ...parsed, personal: { ...defaultProfile.personal, ...parsed.personal }, health: { ...defaultProfile.health, ...parsed.health }, availability: { ...defaultProfile.availability, ...parsed.availability }, emergencyContact: { ...defaultProfile.emergencyContact, ...parsed.emergencyContact }, donation: { ...defaultProfile.donation, ...parsed.donation }, settings: { ...defaultProfile.settings, ...parsed.settings } };
  } catch {
    return defaultProfile;
  }
}

export const ProfileProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [profile, setProfileState] = useState<ProfileData>(defaultProfile);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    setProfileState(loadInitial());
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
    } catch {
      // ignore quota errors
    }
  }, [profile, hydrated]);

  // sync across tabs
  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key === STORAGE_KEY && e.newValue) {
        try {
          setProfileState(JSON.parse(e.newValue));
        } catch { /* noop */ }
      }
    };
    window.addEventListener('storage', onStorage);
    return () => window.removeEventListener('storage', onStorage);
  }, []);

  const setProfile = useCallback((updater: (p: ProfileData) => ProfileData) => {
    setProfileState(prev => updater(prev));
  }, []);

  const updatePersonal = (patch: Partial<ProfileData['personal']>) =>
    setProfile(p => ({ ...p, personal: { ...p.personal, ...patch } }));
  const updateHealth = (patch: Partial<ProfileData['health']>) =>
    setProfile(p => ({ ...p, health: { ...p.health, ...patch } }));
  const updateAvailability = (patch: Partial<ProfileData['availability']>) =>
    setProfile(p => ({ ...p, availability: { ...p.availability, ...patch } }));
  const updateEmergencyContact = (patch: Partial<ProfileData['emergencyContact']>) =>
    setProfile(p => ({ ...p, emergencyContact: { ...p.emergencyContact, ...patch } }));
  const updateDonation = (patch: Partial<ProfileData['donation']>) =>
    setProfile(p => ({ ...p, donation: { ...p.donation, ...patch } }));
  const updateSettings = (patch: Partial<ProfileData['settings']>) =>
    setProfile(p => ({ ...p, settings: { ...p.settings, ...patch } }));

  const saveEligibility = (result: EligibilityResult) =>
    setProfile(p => ({ ...p, eligibility: result }));

  const addAppointment = (appt: AppointmentType) =>
    setProfile(p => ({ ...p, appointments: [...p.appointments, appt] }));

  const updateAppointment = (id: string, patch: Partial<AppointmentType>) =>
    setProfile(p => ({
      ...p,
      appointments: p.appointments.map(a => (a.id === id ? { ...a, ...patch } : a)),
    }));

  const cancelAppointment = (id: string) =>
    updateAppointment(id, { status: 'cancelled' });

  const addReminder = (r: { when: string; reason: string }) =>
    setProfile(p => ({ ...p, reminders: [...p.reminders, { id: crypto.randomUUID(), ...r }] }));

  const computedNextEligibleDate = () => {
    if (profile.eligibility?.nextEligibleDate) return profile.eligibility.nextEligibleDate;
    if (profile.donation.lastDonationDate) {
      const d = new Date(profile.donation.lastDonationDate);
      d.setDate(d.getDate() + 56); // 8 weeks
      return d.toISOString().slice(0, 10);
    }
    return null;
  };

  const totalDonations = profile.donation.history.length;
  const upcomingAppointment = profile.appointments
    .filter(a => a.status === 'upcoming')
    .sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time))[0] ?? null;

  return (
    <ProfileContext.Provider
      value={{
        profile,
        setProfile,
        updatePersonal,
        updateHealth,
        updateAvailability,
        updateEmergencyContact,
        updateDonation,
        updateSettings,
        saveEligibility,
        addAppointment,
        updateAppointment,
        cancelAppointment,
        addReminder,
        computedNextEligibleDate,
        totalDonations,
        upcomingAppointment,
      }}
    >
      {children}
    </ProfileContext.Provider>
  );
};

export const useProfile = () => {
  const ctx = useContext(ProfileContext);
  if (!ctx) throw new Error('useProfile must be used within ProfileProvider');
  return ctx;
};
