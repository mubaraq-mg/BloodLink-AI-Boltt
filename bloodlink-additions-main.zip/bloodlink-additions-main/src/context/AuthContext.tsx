import React, { createContext, useContext, useState } from 'react';

export type UserRole = 'donor' | 'hospital' | 'bank' | 'guest';

interface AuthContextType {
  user: any | null;
  role: UserRole | null;
  onboarded: boolean;
  login: (role: UserRole) => void;
  logout: () => void;
  completeOnboarding: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<any | null>(null);
  const [role, setRole] = useState<UserRole | null>(() => {
    return (localStorage.getItem('role') as UserRole) || null;
  });
  const [onboarded, setOnboarded] = useState(() => {
    return localStorage.getItem('onboarded') === 'true';
  });

  const login = (selectedRole: UserRole) => {
    setUser({ name: 'Musa' });
    setRole(selectedRole);
    localStorage.setItem('role', selectedRole);
  };

  const logout = () => {
    setUser(null);
    setRole(null);
    localStorage.removeItem('role');
  };

  const completeOnboarding = () => {
    setOnboarded(true);
    localStorage.setItem('onboarded', 'true');
  };

  return (
    <AuthContext.Provider value={{ user, role, onboarded, login, logout, completeOnboarding }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};
