import { AuthProvider, useAuth } from "./context/AuthContext";
import { LanguageProvider } from "./context/LanguageContext";
import { ThemeProvider } from "./context/ThemeContext";
import { ProfileProvider } from "./context/ProfileContext";
import { Toaster } from "sonner";
import Auth from "./components/Auth";
import MainLayout from "./components/MainLayout";
import DonorDashboard from "./components/DonorDashboard";
import HospitalDashboard from "./components/HospitalDashboard";
import BankDashboard from "./components/BankDashboard";
import Assistant from "./components/Assistant";
import RequestsList from "./components/RequestsList";
import NotificationsList from "./components/NotificationsList";
import Profile from "./components/Profile";
import AppointmentFlow from "./components/appointments/AppointmentFlow";
import MyAppointments from "./components/appointments/MyAppointments";
import { useState } from "react";

function AppContent() {
  const { role } = useAuth();
  const [activeTab, setActiveTab] = useState("home");

  if (!role) {
    return <Auth />;
  }

  const renderContent = () => {
    if (activeTab === "requests") return <RequestsList />;
    if (activeTab === "assistant") return <Assistant />;
    if (activeTab === "notifications") return <NotificationsList />;
    if (activeTab === "profile") return <Profile setActiveTab={setActiveTab} />;
    if (activeTab === "booking") return <AppointmentFlow setActiveTab={setActiveTab} />;
    if (activeTab === "appointments") return <MyAppointments setActiveTab={setActiveTab} />;

    switch (role) {
      case "donor":
        return <DonorDashboard activeTab={activeTab} setActiveTab={setActiveTab} />;
      case "hospital":
        return <HospitalDashboard activeTab={activeTab} setActiveTab={setActiveTab} />;
      case "bank":
        return <BankDashboard activeTab={activeTab} setActiveTab={setActiveTab} />;
      default:
        return <DonorDashboard activeTab={activeTab} setActiveTab={setActiveTab} />;
    }
  };

  return (
    <MainLayout activeTab={activeTab} setActiveTab={setActiveTab}>
      {renderContent()}
    </MainLayout>
  );
}

function App() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <ProfileProvider>
          <AuthProvider>
            <div className="min-h-screen bg-background text-foreground font-sans">
              <AppContent />
              <Toaster position="top-center" expand={false} richColors />
            </div>
          </AuthProvider>
        </ProfileProvider>
      </LanguageProvider>
    </ThemeProvider>
  );
}

export default App;
