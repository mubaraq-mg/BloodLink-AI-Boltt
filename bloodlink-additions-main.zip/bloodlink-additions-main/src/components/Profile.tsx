import React, { useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { useLanguage, type Language } from '../context/LanguageContext';
import { useProfile } from '../context/ProfileContext';
import { User, Shield, LogOut, Moon, Sun, Bell, Camera, Calendar, Heart, Activity, Phone, Droplet, Settings as SettingsIcon } from 'lucide-react';
import { Button } from './ui/button';
import { Switch } from './ui/switch';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { toast } from 'sonner';

interface Props {
  setActiveTab?: (tab: string) => void;
}

const LANG_LABELS: Record<Language, string> = {
  en: 'English',
  ha: 'Hausa',
  yo: 'Yoruba',
  ig: 'Igbo',
  pcm: 'Nigerian Pidgin',
};

const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
const GENOTYPES = ['AA', 'AS', 'SS', 'AC', 'SC'];
const DAYS = [['mon', 'Mon'], ['tue', 'Tue'], ['wed', 'Wed'], ['thu', 'Thu'], ['fri', 'Fri'], ['sat', 'Sat'], ['sun', 'Sun']] as const;

const Profile: React.FC<Props> = ({ setActiveTab }) => {
  const { user, role, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const { language, setLanguage, t } = useLanguage();
  const { profile, updatePersonal, updateHealth, updateAvailability, updateEmergencyContact, updateDonation, updateSettings, computedNextEligibleDate } = useProfile();
  const fileRef = useRef<HTMLInputElement>(null);

  const handlePhoto = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 500 * 1024) {
      toast.error('Photo must be under 500KB');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => updatePersonal({ photo: reader.result as string });
    reader.readAsDataURL(file);
  };

  const displayName = profile.personal.fullName || user?.name || 'Guest User';
  const photo = profile.personal.photo || `https://api.dicebear.com/7.x/avataaars/svg?seed=${displayName}`;

  return (
    <div className="p-6 space-y-6 max-w-md mx-auto pb-32">
      {/* Header */}
      <div className="flex flex-col items-center pt-4 space-y-4 text-center">
        <div className="w-24 h-24 rounded-[2.5rem] bg-muted flex items-center justify-center border-4 border-primary/20 p-1 relative">
          <img src={photo} alt="avatar" className="rounded-[2rem] w-full h-full object-cover" />
          <button
            onClick={() => fileRef.current?.click()}
            className="absolute -bottom-1 -right-1 w-8 h-8 bg-primary rounded-2xl border-4 border-background flex items-center justify-center"
            aria-label="Change photo"
          >
            <Camera className="w-3 h-3 text-white" />
          </button>
          <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handlePhoto} />
        </div>
        <div>
          <h1 className="text-2xl font-bold">{displayName}</h1>
          <p className="text-sm text-muted-foreground font-medium uppercase tracking-widest">{role} Account</p>
        </div>
      </div>

      <Tabs defaultValue="personal" className="w-full">
        <TabsList className="w-full grid grid-cols-3 h-auto gap-1 bg-muted p-1 rounded-2xl">
          <TabsTrigger value="personal" className="text-xs">Personal</TabsTrigger>
          <TabsTrigger value="health" className="text-xs">Health</TabsTrigger>
          <TabsTrigger value="availability" className="text-xs">Availability</TabsTrigger>
        </TabsList>
        <TabsList className="w-full grid grid-cols-3 h-auto gap-1 bg-muted p-1 rounded-2xl mt-2">
          <TabsTrigger value="emergency" className="text-xs">Emergency</TabsTrigger>
          <TabsTrigger value="donation" className="text-xs">Donation</TabsTrigger>
          <TabsTrigger value="settings" className="text-xs">Settings</TabsTrigger>
        </TabsList>

        {/* PERSONAL */}
        <TabsContent value="personal" className="space-y-4 mt-6">
          <SectionHeader icon={<User className="w-5 h-5" />} title={t('profile.personal')} />
          <Field label="Full Name" value={profile.personal.fullName} onChange={v => updatePersonal({ fullName: v })} />
          <Field label="Date of Birth" type="date" value={profile.personal.dob} onChange={v => updatePersonal({ dob: v })} />
          <div>
            <Label className="text-xs font-bold">Gender</Label>
            <Select value={profile.personal.gender} onValueChange={v => updatePersonal({ gender: v as any })}>
              <SelectTrigger className="mt-1"><SelectValue placeholder="Select gender" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="male">Male</SelectItem>
                <SelectItem value="female">Female</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Field label="Phone" value={profile.personal.phone} onChange={v => updatePersonal({ phone: v })} />
          <Field label="Email" type="email" value={profile.personal.email} onChange={v => updatePersonal({ email: v })} />
          <Field label="Address" value={profile.personal.address} onChange={v => updatePersonal({ address: v })} />
          <div className="grid grid-cols-2 gap-3">
            <Field label="State" value={profile.personal.state} onChange={v => updatePersonal({ state: v })} />
            <Field label="LGA" value={profile.personal.lga} onChange={v => updatePersonal({ lga: v })} />
          </div>
        </TabsContent>

        {/* HEALTH */}
        <TabsContent value="health" className="space-y-4 mt-6">
          <SectionHeader icon={<Heart className="w-5 h-5" />} title={t('profile.health')} />
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs font-bold">Blood Group</Label>
              <Select value={profile.health.bloodGroup} onValueChange={v => updateHealth({ bloodGroup: v })}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {BLOOD_GROUPS.map(g => <SelectItem key={g} value={g}>{g}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs font-bold">Genotype</Label>
              <Select value={profile.health.genotype} onValueChange={v => updateHealth({ genotype: v })}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {GENOTYPES.map(g => <SelectItem key={g} value={g}>{g}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Weight (kg)" value={profile.health.weight} onChange={v => updateHealth({ weight: v })} />
            <Field label="Height (cm)" value={profile.health.height} onChange={v => updateHealth({ height: v })} />
          </div>
          <ListField label="Medical Conditions" value={profile.health.medicalConditions} onChange={v => updateHealth({ medicalConditions: v })} />
          <ListField label="Allergies" value={profile.health.allergies} onChange={v => updateHealth({ allergies: v })} />
          <ListField label="Medications" value={profile.health.medications} onChange={v => updateHealth({ medications: v })} />
        </TabsContent>

        {/* AVAILABILITY */}
        <TabsContent value="availability" className="space-y-4 mt-6">
          <SectionHeader icon={<Calendar className="w-5 h-5" />} title={t('profile.availability')} />
          <div>
            <Label className="text-xs font-bold mb-2 block">Weekly Availability</Label>
            <div className="grid grid-cols-7 gap-1">
              {DAYS.map(([key, label]) => {
                const active = profile.availability.schedule[key];
                return (
                  <button
                    key={key}
                    onClick={() => updateAvailability({ schedule: { ...profile.availability.schedule, [key]: !active } })}
                    className={`p-2 rounded-xl text-xs font-bold transition ${active ? 'bg-primary text-white' : 'bg-muted text-muted-foreground'}`}
                  >
                    {label}
                  </button>
                );
              })}
            </div>
          </div>
          <div className="p-4 rounded-2xl border border-border flex items-center justify-between">
            <div>
              <div className="font-bold text-sm">Emergency Donation</div>
              <div className="text-xs text-muted-foreground">Allow emergency contact for urgent needs</div>
            </div>
            <Switch checked={profile.availability.emergencyDonation} onCheckedChange={v => updateAvailability({ emergencyDonation: v })} />
          </div>
          <div>
            <Label className="text-xs font-bold">Maximum Travel Distance (km): {profile.availability.maxTravelKm}</Label>
            <input
              type="range"
              min={1}
              max={100}
              value={profile.availability.maxTravelKm}
              onChange={e => updateAvailability({ maxTravelKm: Number(e.target.value) })}
              className="w-full mt-2"
            />
          </div>
        </TabsContent>

        {/* EMERGENCY */}
        <TabsContent value="emergency" className="space-y-4 mt-6">
          <SectionHeader icon={<Phone className="w-5 h-5" />} title={t('profile.emergency')} />
          <Field label="Contact Name" value={profile.emergencyContact.name} onChange={v => updateEmergencyContact({ name: v })} />
          <Field label="Relationship" value={profile.emergencyContact.relationship} onChange={v => updateEmergencyContact({ relationship: v })} />
          <Field label="Phone" value={profile.emergencyContact.phone} onChange={v => updateEmergencyContact({ phone: v })} />
        </TabsContent>

        {/* DONATION */}
        <TabsContent value="donation" className="space-y-4 mt-6">
          <SectionHeader icon={<Droplet className="w-5 h-5" />} title={t('profile.donation')} />
          <Field label="Last Donation Date" type="date" value={profile.donation.lastDonationDate} onChange={v => updateDonation({ lastDonationDate: v })} />
          <div className="p-4 rounded-2xl bg-muted border border-border">
            <div className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest">Next Eligible Date</div>
            <div className="text-lg font-bold mt-1">{computedNextEligibleDate() ?? '—'}</div>
          </div>
          <Field label="Preferred Donation Centre" value={profile.donation.preferredCentre} onChange={v => updateDonation({ preferredCentre: v })} />
          <div>
            <Label className="text-xs font-bold">Donation History ({profile.donation.history.length})</Label>
            <div className="mt-2 space-y-2 max-h-40 overflow-auto">
              {profile.donation.history.length === 0 && (
                <div className="p-3 text-xs text-muted-foreground text-center bg-muted rounded-xl">No previous donations</div>
              )}
              {profile.donation.history.map(h => (
                <div key={h.id} className="p-3 bg-card border border-border rounded-xl text-sm flex justify-between">
                  <span>{h.date}</span>
                  <span className="text-muted-foreground">{h.centre}</span>
                </div>
              ))}
            </div>
          </div>
        </TabsContent>

        {/* SETTINGS */}
        <TabsContent value="settings" className="space-y-4 mt-6">
          <SectionHeader icon={<SettingsIcon className="w-5 h-5" />} title={t('profile.settings')} />
          <div className="bg-card border border-border rounded-3xl divide-y divide-border overflow-hidden">
            <SettingRow icon={theme === 'dark' ? <Moon className="w-5 h-5 text-primary" /> : <Sun className="w-5 h-5 text-primary" />} label="Dark Mode">
              <Switch checked={theme === 'dark'} onCheckedChange={toggleTheme} />
            </SettingRow>
            <SettingRow icon={<Bell className="w-5 h-5 text-amber-500" />} label="Notifications">
              <Switch checked={profile.settings.notifications} onCheckedChange={v => updateSettings({ notifications: v })} />
            </SettingRow>
          </div>

          <div>
            <Label className="text-xs font-bold">{t('profile.language')}</Label>
            <Select value={language} onValueChange={(v) => {
              const lang = v as Language;
              setLanguage(lang);
              updateSettings({ preferredLanguage: lang });
              toast.success('Language updated');
            }}>
              <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
              <SelectContent>
                {(Object.keys(LANG_LABELS) as Language[]).map(l => (
                  <SelectItem key={l} value={l}>{LANG_LABELS[l]}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground mt-1">Updates the app and BloodLink AI Assistant instantly.</p>
          </div>

          <Button
            variant="outline"
            onClick={logout}
            className="w-full h-14 rounded-2xl border-2 border-red-500/20 text-red-500 hover:bg-red-500/5 hover:text-red-500 font-bold"
          >
            <LogOut className="w-5 h-5 mr-2" /> Logout
          </Button>
        </TabsContent>
      </Tabs>

      {setActiveTab && (
        <Button variant="outline" onClick={() => setActiveTab('appointments')} className="w-full h-12 rounded-2xl border-2 font-bold">
          <Calendar className="w-4 h-4 mr-2" /> {t('appt.mine')}
        </Button>
      )}

      <p className="text-center text-[10px] text-muted-foreground font-bold uppercase tracking-[0.2em]">
        BloodLink AI v1.0.0
      </p>
    </div>
  );
};

const SectionHeader: React.FC<{ icon: React.ReactNode; title: string }> = ({ icon, title }) => (
  <div className="flex items-center gap-2 mb-2">
    <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center text-primary">{icon}</div>
    <h3 className="font-bold">{title}</h3>
  </div>
);

const Field: React.FC<{ label: string; value: string; onChange: (v: string) => void; type?: string }> = ({ label, value, onChange, type = 'text' }) => (
  <div>
    <Label className="text-xs font-bold">{label}</Label>
    <Input type={type} value={value} onChange={e => onChange(e.target.value)} className="mt-1" />
  </div>
);

const ListField: React.FC<{ label: string; value: string[]; onChange: (v: string[]) => void }> = ({ label, value, onChange }) => (
  <div>
    <Label className="text-xs font-bold">{label} (comma separated)</Label>
    <Textarea
      value={value.join(', ')}
      onChange={e => onChange(e.target.value.split(',').map(s => s.trim()).filter(Boolean))}
      className="mt-1"
      rows={2}
    />
  </div>
);

const SettingRow: React.FC<{ icon: React.ReactNode; label: string; children: React.ReactNode }> = ({ icon, label, children }) => (
  <div className="p-4 flex items-center justify-between">
    <div className="flex items-center gap-3">
      <div className="w-10 h-10 bg-muted rounded-xl flex items-center justify-center">{icon}</div>
      <span className="font-bold text-sm">{label}</span>
    </div>
    {children}
  </div>
);

export default Profile;
