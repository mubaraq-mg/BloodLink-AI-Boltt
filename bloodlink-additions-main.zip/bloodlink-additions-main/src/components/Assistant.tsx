import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLanguage } from '../context/LanguageContext';
import { useProfile } from '../context/ProfileContext';
import { Send, Bot, Sparkles, HelpCircle } from 'lucide-react';
import EligibilityChecker from './EligibilityChecker';

interface Message {
  id: string;
  text: string;
  sender: 'ai' | 'user';
}

const LANG_LABELS: Record<string, string> = { en: 'English', ha: 'Hausa', yo: 'Yoruba', ig: 'Igbo', pcm: 'Pidgin' };

const Assistant: React.FC = () => {
  const { language } = useLanguage();
  const { profile, computedNextEligibleDate } = useProfile();
  const [messages, setMessages] = useState<Message[]>([
    { id: '1', text: "Hello! I'm BloodLink AI. Ask me about your donation eligibility, blood group, or upcoming appointments.", sender: 'ai' }
  ]);
  const [input, setInput] = useState('');
  const [showChecker, setShowChecker] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const buildAnswer = (query: string): string => {
    const q = query.toLowerCase();
    const langNote = language !== 'en' ? ` (${LANG_LABELS[language]})` : '';

    if (/blood group|blood type/.test(q) && /my/.test(q)) {
      return `Your blood group is ${profile.health.bloodGroup || 'not set yet — update it in Profile → Health'}.${langNote}`;
    }
    if (/genotype/.test(q) && /my/.test(q)) {
      return `Your genotype is ${profile.health.genotype || 'not set yet'}.`;
    }
    if (/am i eligible|eligible/.test(q)) {
      if (!profile.eligibility) return "You haven't completed the AI eligibility check yet. Would you like to start it now?";
      const map: Record<string, string> = {
        eligible: '🟢 You are Eligible based on your latest assessment.',
        screening: '🟡 You Need Further Screening before donating.',
        ineligible: '🔴 You are Temporarily Ineligible.',
      };
      return `${map[profile.eligibility.status]} ${profile.eligibility.recommendation}`;
    }
    if (/when.*donate|next.*donate|next eligible/.test(q)) {
      const next = computedNextEligibleDate();
      return next ? `Your next eligible donation date is ${next}.` : "No previous donation on record — if you're eligible, you can donate now.";
    }
    if (/donation history|my.*history|past donations/.test(q)) {
      if (profile.donation.history.length === 0) return 'No donations recorded yet in your history.';
      return `You have ${profile.donation.history.length} recorded donation(s): ${profile.donation.history.map(h => `${h.date} at ${h.centre}`).join('; ')}.`;
    }
    if (/availability|when.*free/.test(q)) {
      const days = Object.entries(profile.availability.schedule).filter(([, v]) => v).map(([k]) => k).join(', ');
      return `You are available on: ${days || 'no days selected'}. Emergency donation: ${profile.availability.emergencyDonation ? 'On' : 'Off'}. Max travel: ${profile.availability.maxTravelKm}km.`;
    }
    if (/upcoming.*appointment|next appointment/.test(q)) {
      const upc = profile.appointments.find(a => a.status === 'upcoming');
      return upc ? `Your next appointment is at ${upc.hospitalName} on ${upc.date} at ${upc.time}.` : 'You have no upcoming appointments. Would you like to book one?';
    }
    if (/malaria/.test(q)) {
      return 'You can usually donate blood 4 weeks after fully recovering from malaria. Screening is always required.';
    }
    if (/compatible|blood type/.test(q)) {
      return 'O-negative is the universal donor, and AB-positive is the universal recipient.';
    }
    return "I can help with your blood group, eligibility, next donation date, donation history, availability, and appointments. Try asking one of the suggestions below.";
  };

  const handleSend = (override?: string) => {
    const value = (override ?? input).trim();
    if (!value) return;
    const userMsg: Message = { id: Date.now().toString(), text: value, sender: 'user' };
    setMessages(prev => [...prev, userMsg]);
    setInput('');

    setTimeout(() => {
      const aiMsg: Message = { id: (Date.now() + 1).toString(), text: buildAnswer(value), sender: 'ai' };
      setMessages(prev => [...prev, aiMsg]);
    }, 500);
  };

  const suggestions = [
    'What is my blood group?',
    'Am I eligible?',
    'When can I donate again?',
    'Show my donation history',
    'What is my availability?',
    'Check my eligibility',
  ];

  if (showChecker) {
    return <EligibilityChecker onBack={() => setShowChecker(false)} />;
  }

  return (
    <div className="flex flex-col h-[calc(100vh-144px)] max-w-md mx-auto relative">
      <div className="p-6 bg-background/80 backdrop-blur-md sticky top-0 z-10 border-b border-border/50">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-primary rounded-2xl flex items-center justify-center shadow-lg shadow-primary/20">
            <Bot className="w-7 h-7 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold">BloodLink AI</h2>
            <p className="text-xs text-emerald-500 font-bold flex items-center gap-1">
              <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" /> Online · {LANG_LABELS[language]}
            </p>
          </div>
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6 scroll-smooth">
        <AnimatePresence>
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-[85%] p-4 rounded-3xl ${
                msg.sender === 'user'
                  ? 'bg-primary text-white rounded-tr-none shadow-lg shadow-primary/10'
                  : 'bg-card border border-border rounded-tl-none shadow-sm'
              }`}>
                <p className="text-sm font-medium leading-relaxed whitespace-pre-wrap">{msg.text}</p>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      <div className="p-6 space-y-4 bg-background/80 backdrop-blur-md">
        <div className="flex gap-2 overflow-x-auto no-scrollbar -mx-6 px-6 pb-2">
          {suggestions.map((s, i) => (
            <button
              key={i}
              onClick={() => {
                if (s === 'Check my eligibility') setShowChecker(true);
                else handleSend(s);
              }}
              className="whitespace-nowrap px-4 py-2 bg-muted/50 rounded-full text-xs font-bold border border-border/50 hover:bg-primary/5 hover:border-primary/50 transition-all flex items-center gap-2"
            >
              {s === 'Check my eligibility' ? <Sparkles className="w-3 h-3 text-primary" /> : <HelpCircle className="w-3 h-3" />}
              {s}
            </button>
          ))}
        </div>

        <div className="relative">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ask me anything..."
            className="w-full h-14 pl-6 pr-14 bg-card border-2 border-border rounded-2xl focus:border-primary focus:ring-0 outline-none transition-all font-medium"
          />
          <button
            onClick={() => handleSend()}
            disabled={!input.trim()}
            className="absolute right-2 top-2 w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-white disabled:opacity-50 transition-all active:scale-90"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>

        <p className="text-[9px] text-center text-muted-foreground font-bold uppercase tracking-widest">
          AI assistant may provide inaccurate information. Consult a doctor.
        </p>
      </div>
    </div>
  );
};

export default Assistant;
