import React from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Search, MapPin, MoreHorizontal, Plus, Package, TrendingUp, Users } from 'lucide-react';

interface BankDashboardProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const BankDashboard: React.FC<BankDashboardProps> = ({ activeTab, setActiveTab }) => {
  const inventory = [
    { type: 'A+', units: 45, status: 'stable' },
    { type: 'O+', units: 12, status: 'low' },
    { type: 'B-', units: 3, status: 'critical' },
    { type: 'AB+', units: 28, status: 'stable' },
  ];

  return (
    <div className="p-6 space-y-8 max-w-md mx-auto">
      <div className="flex justify-between items-start pt-4">
        <div>
          <h2 className="text-muted-foreground font-medium">Red Cross Lagos</h2>
          <h1 className="text-3xl font-bold">Inventory</h1>
        </div>
        <Button size="icon" className="w-12 h-12 rounded-2xl bg-primary shadow-lg shadow-primary/20">
          <Plus className="w-6 h-6" />
        </Button>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Card className="p-5 rounded-[2rem] border-none bg-primary text-white space-y-2">
          <TrendingUp className="w-6 h-6 opacity-80" />
          <div>
            <p className="text-[10px] font-bold uppercase tracking-widest opacity-80">Total Units</p>
            <p className="text-3xl font-black">1,248</p>
          </div>
        </Card>
        <Card className="p-5 rounded-[2rem] border border-border bg-card space-y-2">
          <Users className="w-6 h-6 text-primary" />
          <div>
            <p className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Donors Today</p>
            <p className="text-3xl font-black">24</p>
          </div>
        </Card>
      </div>

      <div className="space-y-4">
        <div className="flex justify-between items-center px-2">
          <h3 className="font-bold text-xl">Stock Levels</h3>
          <button className="text-primary font-bold text-sm">Update</button>
        </div>

        <div className="grid grid-cols-2 gap-4">
          {inventory.map((item, i) => (
            <Card key={i} className="p-5 rounded-3xl border border-border bg-card space-y-4">
              <div className="flex justify-between items-start">
                <div className="w-12 h-12 rounded-2xl bg-muted flex items-center justify-center font-black text-xl">
                  {item.type}
                </div>
                <div className={`w-2 h-2 rounded-full ${
                  item.status === 'critical' ? 'bg-red-500' : 
                  item.status === 'low' ? 'bg-amber-500' : 'bg-emerald-500'
                }`} />
              </div>
              <div>
                <p className="text-2xl font-black">{item.units} <span className="text-xs text-muted-foreground font-bold">Units</span></p>
                <p className={`text-[10px] font-bold uppercase tracking-widest ${
                  item.status === 'critical' ? 'text-red-500' : 
                  item.status === 'low' ? 'text-amber-500' : 'text-emerald-500'
                }`}>{item.status}</p>
              </div>
            </Card>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="font-bold text-xl px-2">Incoming Requests</h3>
        {[
          { from: 'Lagos University Hospital', units: '5 O+', time: '2m ago' },
          { from: 'Eko Clinic', units: '2 B-', time: '15m ago' },
        ].map((req, i) => (
          <div key={i} className="flex items-center justify-between p-4 bg-muted/30 rounded-2xl border border-border/50">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center">
                <Package className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="font-bold text-sm">{req.from}</p>
                <p className="text-xs text-muted-foreground">{req.units}</p>
              </div>
            </div>
            <span className="text-[10px] font-bold text-muted-foreground uppercase">{req.time}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default BankDashboard;
