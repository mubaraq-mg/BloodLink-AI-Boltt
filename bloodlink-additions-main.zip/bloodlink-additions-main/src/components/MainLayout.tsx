import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { Home, ClipboardList, MessageCircle, Bell, User, Droplet } from 'lucide-react';

interface MainLayoutProps {
  children: React.ReactNode;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const MainLayout: React.FC<MainLayoutProps> = ({ children, activeTab, setActiveTab }) => {
  const { t } = useLanguage();

  const navItems = [
    { id: 'home', label: 'nav.home', icon: Home },
    { id: 'requests', label: 'nav.requests', icon: ClipboardList },
    { id: 'assistant', label: 'nav.assistant', icon: MessageCircle },
    { id: 'notifications', label: 'nav.notifications', icon: Bell },
    { id: 'profile', label: 'nav.profile', icon: User },
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col md:flex-row">
      {/* Desktop / Tablet Sidebar */}
      <aside className="hidden md:flex md:flex-col md:w-20 lg:w-64 md:sticky md:top-0 md:h-screen border-r border-border/50 bg-card/30 backdrop-blur-xl px-3 lg:px-4 py-6 gap-2 shrink-0 z-40">
        <div className="flex items-center gap-3 px-2 mb-6">
          <div className="w-10 h-10 rounded-2xl bg-primary/15 grid place-items-center shrink-0">
            <Droplet className="w-5 h-5 text-primary fill-primary/30" />
          </div>
          <span className="hidden lg:block font-black text-lg tracking-tight truncate">BloodLink AI</span>
        </div>
        <nav className="flex flex-col gap-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                aria-label={t(item.label)}
                className={`flex items-center gap-3 lg:gap-4 px-3 py-3 rounded-2xl transition-all duration-200 ${
                  isActive
                    ? 'bg-primary/15 text-primary font-bold'
                    : 'text-muted-foreground hover:bg-muted/50 hover:text-foreground'
                }`}
              >
                <Icon className={`w-5 h-5 shrink-0 ${isActive ? 'fill-primary/10' : ''}`} />
                <span className="hidden lg:block text-sm truncate">{t(item.label)}</span>
              </button>
            );
          })}
        </nav>
      </aside>

      {/* Main content */}
      <main className="flex-1 min-w-0 pb-28 md:pb-8 overflow-y-auto">
        <div className="mx-auto w-full max-w-4xl xl:max-w-6xl md:px-6 lg:px-10">
          {children}
        </div>
      </main>

      {/* Mobile Bottom Nav */}
      <nav
        className="md:hidden fixed bottom-4 left-4 right-4 sm:left-6 sm:right-6 h-16 glass-card rounded-3xl flex items-center justify-around px-2 z-50"
        style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
      >
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              aria-label={t(item.label)}
              className={`flex flex-col items-center justify-center gap-1 transition-all duration-300 relative flex-1 ${
                isActive ? 'text-primary' : 'text-muted-foreground'
              }`}
            >
              {isActive && (
                <div className="absolute -top-1 w-1 h-1 bg-primary rounded-full" />
              )}
              <Icon className={`w-5 h-5 sm:w-6 sm:h-6 ${isActive ? 'fill-primary/10' : ''}`} />
              <span className="text-[10px] font-bold uppercase tracking-wider">
                {t(item.label).split(' ')[0]}
              </span>
            </button>
          );
        })}
      </nav>
    </div>
  );
};

export default MainLayout;
