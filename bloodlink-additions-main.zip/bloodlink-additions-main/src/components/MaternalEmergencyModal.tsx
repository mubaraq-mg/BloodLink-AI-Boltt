import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertCircle, X, MapPin, Clock, Heart } from 'lucide-react';
import { Button } from './ui/button';
import { useLanguage } from '../context/LanguageContext';

interface MaternalEmergencyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const MaternalEmergencyModal: React.FC<MaternalEmergencyModalProps> = ({ isOpen, onClose }) => {
  const { t } = useLanguage();

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          />
          
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="relative w-full max-w-md bg-card rounded-[2.5rem] p-8 space-y-6 shadow-2xl border-2 border-red-500"
          >
            <div className="flex justify-between items-start">
              <div className="bg-red-500/10 p-4 rounded-3xl">
                <Heart className="w-10 h-10 text-red-500 fill-red-500/20" />
              </div>
              <button onClick={onClose} className="p-2 hover:bg-muted rounded-full transition-colors">
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="space-y-2">
              <div className="inline-flex items-center gap-2 bg-red-500 text-[10px] text-white px-3 py-1 rounded-full font-black uppercase tracking-widest animate-pulse">
                <AlertCircle className="w-3 h-3" /> Critical Priority
              </div>
              <h2 className="text-3xl font-bold leading-tight">{t('maternal.title')}</h2>
              <p className="text-muted-foreground text-lg">{t('maternal.desc')}</p>
            </div>

            <div className="bg-muted/30 rounded-3xl p-6 space-y-4">
              <div className="flex justify-between items-center pb-4 border-b border-border/50">
                <span className="text-muted-foreground font-medium">Mother's Blood Group</span>
                <span className="text-2xl font-black text-primary">O-</span>
              </div>
              <div className="flex justify-between items-center pb-4 border-b border-border/50">
                <span className="text-muted-foreground font-medium">Location</span>
                <span className="font-bold flex items-center gap-1">
                  <MapPin className="w-4 h-4 text-red-500" /> General Hospital
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground font-medium">Urgency</span>
                <span className="text-red-500 font-bold flex items-center gap-1">
                  <Clock className="w-4 h-4" /> Immediate
                </span>
              </div>
            </div>

            <div className="space-y-3">
              <Button className="w-full h-16 rounded-2xl text-xl font-bold bg-red-600 hover:bg-red-700 shadow-xl shadow-red-500/20">
                I Can Donate Now
              </Button>
              <Button variant="ghost" onClick={onClose} className="w-full h-12 rounded-xl text-muted-foreground font-bold">
                Maybe Later
              </Button>
            </div>
            
            <p className="text-center text-[10px] text-muted-foreground uppercase font-bold tracking-widest">
              AI Smart Matching is prioritising donors within 2km
            </p>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default MaternalEmergencyModal;
