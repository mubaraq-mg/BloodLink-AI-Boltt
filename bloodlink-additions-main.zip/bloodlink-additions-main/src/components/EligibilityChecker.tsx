import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, CheckCircle2, AlertCircle, ArrowRight, Info } from 'lucide-react';
import { Button } from './ui/button';
import { useProfile, type EligibilityResult, type EligibilityStatus } from '../context/ProfileContext';
import { useLanguage } from '../context/LanguageContext';
import { toast } from 'sonner';

interface EligibilityCheckerProps {
  onBack: () => void;
}

const QUESTIONS = [
  { id: 1, text: "Have you donated blood within the last 3 months?", options: ["Yes", "No"] },
  { id: 2, text: "Are you feeling well and healthy today?", options: ["Yes", "No"] },
  { id: 3, text: "Have you recently had malaria or any other infection?", options: ["Yes", "No"] },
  { id: 4, text: "Are you between 18 and 65 years old?", options: ["Yes", "No"] },
  { id: 5, text: "Is your weight above 50kg?", options: ["Yes", "No"] },
];

function analyse(answers: string[]): EligibilityResult {
  const [q1, q2, q3, q4, q5] = answers;
  const date = new Date().toISOString();
  // Hard blocks
  if (q4 === 'No' || q5 === 'No') {
    return {
      status: 'ineligible',
      date,
      recommendation: 'You do not meet the basic donation requirements at this time.',
      reason: q4 === 'No' ? 'Age must be between 18–65 years.' : 'Weight must be above 50kg.',
    };
  }
  if (q1 === 'Yes') {
    const next = new Date();
    next.setDate(next.getDate() + 56);
    return {
      status: 'ineligible',
      date,
      recommendation: 'Wait until the recommended donation interval has passed.',
      reason: 'Recent donation within the last 3 months.',
      nextEligibleDate: next.toISOString().slice(0, 10),
    };
  }
  if (q3 === 'Yes' || q2 === 'No') {
    const next = new Date();
    next.setDate(next.getDate() + 28);
    return {
      status: 'screening',
      date,
      recommendation: 'Visit a certified centre for further health screening before donating.',
      nextEligibleDate: next.toISOString().slice(0, 10),
    };
  }
  return {
    status: 'eligible',
    date,
    recommendation: 'You appear eligible. Book an appointment at your preferred centre.',
  };
}

const STATUS_META: Record<EligibilityStatus, { emoji: string; color: string; label: string; icon: typeof CheckCircle2 }> = {
  eligible: { emoji: '🟢', color: 'emerald-500', label: 'Eligible', icon: CheckCircle2 },
  screening: { emoji: '🟡', color: 'amber-500', label: 'Needs Further Screening', icon: AlertCircle },
  ineligible: { emoji: '🔴', color: 'red-500', label: 'Temporarily Ineligible', icon: AlertCircle },
};

const EligibilityChecker: React.FC<EligibilityCheckerProps> = ({ onBack }) => {
  const { saveEligibility } = useProfile();
  const { t } = useLanguage();
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<string[]>([]);
  const [result, setResult] = useState<EligibilityResult | null>(null);

  const handleAnswer = (answer: string) => {
    const newAnswers = [...answers, answer];
    setAnswers(newAnswers);

    if (step < QUESTIONS.length - 1) {
      setStep(step + 1);
    } else {
      setResult(analyse(newAnswers));
    }
  };

  const handleSave = () => {
    if (!result) return;
    saveEligibility(result);
    toast.success('Assessment saved to your profile');
    onBack();
  };

  return (
    <div className="flex flex-col min-h-screen bg-background p-6 pb-32">
      <button onClick={onBack} className="flex items-center gap-2 text-muted-foreground font-bold mb-8">
        <ChevronLeft className="w-5 h-5" /> Back
      </button>

      <div className="flex-1">
        <AnimatePresence mode="wait">
          {!result ? (
            <motion.div
              key={step}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-10"
            >
              <div className="space-y-2">
                <div className="flex justify-between items-end">
                  <span className="text-primary font-black text-4xl">0{step + 1}</span>
                  <span className="text-muted-foreground font-bold">Question {step + 1} of {QUESTIONS.length}</span>
                </div>
                <div className="h-1.5 w-full bg-muted rounded-full">
                  <motion.div
                    className="h-full bg-primary rounded-full"
                    initial={{ width: 0 }}
                    animate={{ width: `${((step + 1) / QUESTIONS.length) * 100}%` }}
                  />
                </div>
              </div>

              <h2 className="text-2xl font-bold leading-tight">{QUESTIONS[step].text}</h2>

              <div className="space-y-4">
                {QUESTIONS[step].options.map((opt) => (
                  <button
                    key={opt}
                    onClick={() => handleAnswer(opt)}
                    className="w-full p-6 rounded-[2rem] border-2 border-border bg-card text-left font-bold text-xl hover:border-primary hover:bg-primary/5 transition-all flex justify-between items-center group"
                  >
                    {opt}
                    <ArrowRight className="w-6 h-6 text-primary opacity-0 group-hover:opacity-100 -translate-x-2 group-hover:translate-x-0 transition-all" />
                  </button>
                ))}
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="result"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="space-y-6 pt-4"
            >
              {(() => {
                const meta = STATUS_META[result.status];
                const Icon = meta.icon;
                return (
                  <div className="text-center space-y-4">
                    <div className={`w-24 h-24 mx-auto rounded-full flex items-center justify-center bg-${meta.color}/10`}>
                      <Icon className={`w-12 h-12 text-${meta.color}`} />
                    </div>
                    <div>
                      <div className="text-4xl mb-2">{meta.emoji}</div>
                      <h2 className="text-3xl font-bold">{meta.label}</h2>
                    </div>
                  </div>
                );
              })()}

              <div className="bg-card border border-border rounded-3xl p-5 space-y-3">
                <Row label={t('eligibility.assessedOn')} value={new Date(result.date).toLocaleDateString()} />
                <Row label="Recommendation" value={result.recommendation} />
                {result.reason && <Row label="Reason" value={result.reason} />}
                {result.nextEligibleDate && <Row label={t('eligibility.nextEligible')} value={result.nextEligibleDate} highlight />}
              </div>

              <div className="p-4 bg-muted/50 rounded-2xl flex items-start gap-3 text-left">
                <Info className="w-5 h-5 text-muted-foreground mt-0.5 shrink-0" />
                <p className="text-xs text-muted-foreground font-medium">{t('eligibility.disclaimer')}</p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <Button variant="outline" onClick={() => { setResult(null); setStep(0); setAnswers([]); }} className="h-14 rounded-2xl border-2 font-bold">
                  Retake
                </Button>
                <Button onClick={handleSave} className="h-14 rounded-2xl font-bold">
                  {t('eligibility.saveContinue')}
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

const Row: React.FC<{ label: string; value: string; highlight?: boolean }> = ({ label, value, highlight }) => (
  <div>
    <div className="text-[10px] uppercase font-bold tracking-widest text-muted-foreground">{label}</div>
    <div className={`font-bold ${highlight ? 'text-primary' : ''}`}>{value}</div>
  </div>
);

export default EligibilityChecker;
