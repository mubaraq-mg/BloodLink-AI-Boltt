import React from 'react';
import { motion } from 'framer-motion';
import { MapPin, Calendar as CalIcon, Clock, FileText, Droplet, Activity } from 'lucide-react';
import { Button } from '../ui/button';
import { useLanguage } from '../../context/LanguageContext';

interface Props {
  hospital: { id: string; name: string; address: string; phone: string };
  date: string;
  time: string;
  type: 'donation' | 'screening';
  notes: string;
  onNotesChange: (v: string) => void;
  onConfirm: () => void;
}

const AppointmentSummary: React.FC<Props> = ({ hospital, date, time, type, notes, onNotesChange, onConfirm }) => {
  const { t } = useLanguage();
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
      <h2 className="text-2xl font-bold">{t('appt.summary')}</h2>
      <div className="bg-card border border-border rounded-3xl divide-y divide-border">
        <Row icon={type === 'donation' ? <Droplet className="w-5 h-5 text-primary" /> : <Activity className="w-5 h-5 text-emerald-500" />} label="Type" value={t(`appt.type.${type}`)} />
        <Row icon={<MapPin className="w-5 h-5 text-blue-500" />} label="Hospital" value={hospital.name} sub={hospital.address} />
        <Row icon={<CalIcon className="w-5 h-5 text-amber-500" />} label="Date" value={date} />
        <Row icon={<Clock className="w-5 h-5 text-purple-500" />} label="Time" value={time} />
      </div>

      <div className="space-y-2">
        <label className="flex items-center gap-2 text-sm font-bold">
          <FileText className="w-4 h-4" /> Notes (optional)
        </label>
        <textarea
          value={notes}
          onChange={e => onNotesChange(e.target.value)}
          placeholder="Any specific needs or medical info…"
          className="w-full min-h-24 p-4 rounded-2xl border-2 border-border bg-card font-medium focus:border-primary outline-none"
        />
      </div>

      <Button onClick={onConfirm} className="w-full h-14 rounded-2xl font-bold text-lg">
        {t('appt.confirm')}
      </Button>
    </motion.div>
  );
};

const Row: React.FC<{ icon: React.ReactNode; label: string; value: string; sub?: string }> = ({ icon, label, value, sub }) => (
  <div className="p-4 flex items-center gap-4">
    <div className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center">{icon}</div>
    <div className="flex-1">
      <div className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest">{label}</div>
      <div className="font-bold">{value}</div>
      {sub && <div className="text-xs text-muted-foreground">{sub}</div>}
    </div>
  </div>
);

export default AppointmentSummary;
