import React, { useState } from 'react';
import { ChevronLeft, Calendar as CalIcon, Plus } from 'lucide-react';
import { Button } from '../ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { useProfile, type AppointmentType } from '../../context/ProfileContext';
import { useLanguage } from '../../context/LanguageContext';
import AppointmentDetails from './AppointmentDetails';

interface Props {
  setActiveTab: (tab: string) => void;
}

const MyAppointments: React.FC<Props> = ({ setActiveTab }) => {
  const { profile } = useProfile();
  const { t } = useLanguage();
  const [selected, setSelected] = useState<AppointmentType | null>(null);

  if (selected) {
    return <AppointmentDetails appointment={selected} onBack={() => setSelected(null)} />;
  }

  const upcoming = profile.appointments.filter(a => a.status === 'upcoming').sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));
  const history = profile.appointments.filter(a => a.status !== 'upcoming').sort((a, b) => (b.date + b.time).localeCompare(a.date + a.time));

  return (
    <div className="p-6 space-y-6 max-w-md mx-auto pb-32">
      <button onClick={() => setActiveTab('home')} className="flex items-center gap-2 text-muted-foreground font-bold">
        <ChevronLeft className="w-5 h-5" /> Back
      </button>

      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold">{t('appt.mine')}</h2>
        <Button size="sm" onClick={() => setActiveTab('booking')} className="rounded-xl font-bold">
          <Plus className="w-4 h-4 mr-1" /> New
        </Button>
      </div>

      <Tabs defaultValue="upcoming" className="w-full">
        <TabsList className="grid grid-cols-2 w-full">
          <TabsTrigger value="upcoming">{t('appt.upcoming')} ({upcoming.length})</TabsTrigger>
          <TabsTrigger value="history">{t('appt.history')} ({history.length})</TabsTrigger>
        </TabsList>
        <TabsContent value="upcoming" className="space-y-3 mt-4">
          {upcoming.length === 0 && <EmptyState label="No upcoming appointments" />}
          {upcoming.map(a => <ApptCard key={a.id} appt={a} onClick={() => setSelected(a)} />)}
        </TabsContent>
        <TabsContent value="history" className="space-y-3 mt-4">
          {history.length === 0 && <EmptyState label="No past appointments" />}
          {history.map(a => <ApptCard key={a.id} appt={a} onClick={() => setSelected(a)} />)}
        </TabsContent>
      </Tabs>
    </div>
  );
};

const ApptCard: React.FC<{ appt: AppointmentType; onClick: () => void }> = ({ appt, onClick }) => (
  <button
    onClick={onClick}
    className="w-full p-5 rounded-3xl bg-card border border-border text-left hover:border-primary/50 transition"
  >
    <div className="flex justify-between items-start">
      <div>
        <div className="font-bold">{appt.hospitalName}</div>
        <div className="text-xs text-muted-foreground mt-1 flex items-center gap-2">
          <CalIcon className="w-3 h-3" /> {appt.date} · {appt.time}
        </div>
      </div>
      <span className="text-[10px] px-2 py-1 rounded-full bg-muted font-bold uppercase">
        {appt.type === 'donation' ? '🩸' : '🩺'} {appt.type}
      </span>
    </div>
  </button>
);

const EmptyState: React.FC<{ label: string }> = ({ label }) => (
  <div className="p-8 text-center text-muted-foreground text-sm">{label}</div>
);

export default MyAppointments;
