import React from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../../context/LanguageContext';

interface Props {
  value: string;
  onSelect: (time: string) => void;
}

const TIMES = ['08:00', '08:30', '09:00', '09:30', '10:00', '10:30', '11:00', '11:30', '12:00', '14:00', '14:30', '15:00', '15:30', '16:00'];

const SelectTime: React.FC<Props> = ({ value, onSelect }) => {
  const { t } = useLanguage();
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
      <h2 className="text-2xl font-bold">{t('appt.selectTime')}</h2>
      <div className="grid grid-cols-3 gap-3">
        {TIMES.map(time => (
          <button
            key={time}
            onClick={() => onSelect(time)}
            className={`p-4 rounded-2xl border-2 font-bold transition ${
              value === time
                ? 'border-primary bg-primary text-white'
                : 'border-border bg-card hover:border-primary/50'
            }`}
          >
            {time}
          </button>
        ))}
      </div>
    </motion.div>
  );
};

export default SelectTime;
