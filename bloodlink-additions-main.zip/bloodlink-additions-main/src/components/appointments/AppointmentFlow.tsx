import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, MapPin, AlertCircle, Bell, MessageCircle } from 'lucide-react';
import { useProfile, type AppointmentType } from '../../context/ProfileContext';
import { useLanguage } from '../../context/LanguageContext';
import { Button } from '../ui/button';
import SelectDate from './SelectDate';
import SelectTime from './SelectTime';
import AppointmentSummary from './AppointmentSummary';
import AppointmentConfirmation from './AppointmentConfirmation';
import { toast } from 'sonner';

interface Props {
  setActiveTab: (tab: string) => void;
  rescheduleFor?: AppointmentType | null;
  onDone?: () => void;
}

const HOSPITALS = [
  { id: 'h1', name: 'National Hospital Abuja', phone: '+2348012345678', address: 'Central Area, Abuja' },
  { id: 'h2', name: 'Lagos University Teaching Hospital', phone: '+2348023456789', address: 'Idi-Araba, Lagos' },
  { id: 'h3', name: 'Ahmadu Bello University Teaching Hospital', phone: '+2348034567890', address: 'Zaria, Kaduna' },
];

type Step = 'gate' | 'hospital' | 'date' | 'time' | 'summary' | 'confirm';

const AppointmentFlow: React.FC<Props> = ({ setActiveTab, rescheduleFor, onDone }) => {
  const { profile, addAppointment, updateAppointment, addReminder } = useProfile();
  const { t } = useLanguage();
  const eligibility = profile.eligibility;

  const [step, setStep] = useState<Step>(rescheduleFor ? 'date' : 'gate');
  const [hospitalId, setHospitalId] = useState<string>(rescheduleFor?.hospitalId ?? '');
  const [date, setDate] = useState<string>(rescheduleFor?.date ?? '');
  const [time, setTime] = useState<string>(rescheduleFor?.time ?? '');
  const [apptType, setApptType] = useState<'donation' | 'screening'>(
    rescheduleFor?.type ?? (eligibility?.status === 'screening' ? 'screening' : 'donation')
  );
  const [notes, setNotes] = useState<string>(rescheduleFor?.notes ?? '');
  const [confirmed, setConfirmed] = useState<AppointmentType | null>(null);

  const hospital = HOSPITALS.find(h => h.id === hospitalId);

  const back = () => {
    if (step === 'gate') setActiveTab('home');
    else if (step === 'hospital') setStep('gate');
    else if (step === 'date') setStep(rescheduleFor ? 'summary' : 'hospital');
    else if (step === 'time') setStep('date');
    else if (step === 'summary') setStep('time');
    else if (step === 'confirm') {
      setActiveTab('appointments');
      onDone?.();
    }
  };

  const handleConfirm = () => {
    if (!hospital) return;
    const code = 'BL-' + Math.random().toString(36).slice(2, 8).toUpperCase();
    if (rescheduleFor) {
      updateAppointment(rescheduleFor.id, { date, time, notes, type: apptType, status: 'upcoming' });
      const updated: AppointmentType = { ...rescheduleFor, date, time, notes, type: apptType, status: 'upcoming' };
      setConfirmed(updated);
      toast.success('Appointment rescheduled');
    } else {
      const appt: AppointmentType = {
        id: crypto.randomUUID(),
        hospitalId: hospital.id,
        hospitalName: hospital.name,
        hospitalPhone: hospital.phone,
        hospitalAddress: hospital.address,
        date,
        time,
        type: apptType,
        notes,
        status: 'upcoming',
        confirmationCode: code,
        createdAt: new Date().toISOString(),
      };
      addAppointment(appt);
      setConfirmed(appt);
      toast.success('Appointment booked');
    }
    setStep('confirm');
  };

  // Ineligible gate
  if (step === 'gate' && eligibility?.status === 'ineligible') {
    return (
      <div className="p-6 space-y-6 max-w-md mx-auto">
        <button onClick={() => setActiveTab('home')} className="flex items-center gap-2 text-muted-foreground font-bold">
          <ChevronLeft className="w-5 h-5" /> Back
        </button>
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
          <div className="w-20 h-20 bg-red-500/10 rounded-3xl flex items-center justify-center mx-auto">
            <AlertCircle className="w-10 h-10 text-red-500" />
          </div>
          <div className="text-center space-y-2">
            <h2 className="text-2xl font-bold">{t('appt.blockedTitle')}</h2>
            <p className="text-muted-foreground">{eligibility.reason || 'You are temporarily ineligible to donate.'}</p>
            {eligibility.nextEligibleDate && (
              <p className="text-sm font-bold text-primary">{t('eligibility.nextEligible')}: {eligibility.nextEligibleDate}</p>
            )}
          </div>
          <div className="space-y-3">
            <Button
              onClick={() => {
                addReminder({ when: eligibility.nextEligibleDate ?? new Date().toISOString().slice(0, 10), reason: 'Donation eligibility reminder' });
                toast.success('Reminder set');
              }}
              className="w-full h-14 rounded-2xl font-bold"
            >
              <Bell className="w-5 h-5 mr-2" /> {t('appt.setReminder')}
            </Button>
            <Button
              variant="outline"
              onClick={() => setActiveTab('assistant')}
              className="w-full h-14 rounded-2xl border-2 font-bold"
            >
              <MessageCircle className="w-5 h-5 mr-2" /> {t('appt.chatAI')}
            </Button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 max-w-md mx-auto pb-32">
      <button onClick={back} className="flex items-center gap-2 text-muted-foreground font-bold">
        <ChevronLeft className="w-5 h-5" /> Back
      </button>

      <AnimatePresence mode="wait">
        {step === 'gate' && (
          <motion.div key="gate" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-6">
            <div>
              <h2 className="text-3xl font-bold">Book Appointment</h2>
              <p className="text-muted-foreground text-sm mt-1">Choose appointment type</p>
            </div>
            <div className="space-y-3">
              <button
                onClick={() => { setApptType('donation'); setStep('hospital'); }}
                disabled={eligibility?.status === 'screening'}
                className="w-full p-6 rounded-3xl border-2 border-border bg-card text-left disabled:opacity-40 disabled:cursor-not-allowed hover:border-primary transition"
              >
                <div className="font-bold text-lg">🩸 {t('appt.type.donation')}</div>
                <p className="text-sm text-muted-foreground mt-1">
                  {eligibility?.status === 'screening'
                    ? 'Requires eligibility screening first'
                    : 'Donate blood at a certified centre'}
                </p>
              </button>
              <button
                onClick={() => { setApptType('screening'); setStep('hospital'); }}
                className="w-full p-6 rounded-3xl border-2 border-border bg-card text-left hover:border-primary transition"
              >
                <div className="font-bold text-lg">🩺 {t('appt.type.screening')}</div>
                <p className="text-sm text-muted-foreground mt-1">Health check-up and eligibility screening</p>
              </button>
            </div>
          </motion.div>
        )}

        {step === 'hospital' && (
          <motion.div key="hospital" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-4">
            <h2 className="text-2xl font-bold">Select Hospital</h2>
            <div className="space-y-3">
              {HOSPITALS.map(h => (
                <button
                  key={h.id}
                  onClick={() => { setHospitalId(h.id); setStep('date'); }}
                  className={`w-full p-5 rounded-3xl border-2 text-left transition ${
                    hospitalId === h.id ? 'border-primary bg-primary/5' : 'border-border bg-card hover:border-primary/50'
                  }`}
                >
                  <div className="font-bold">{h.name}</div>
                  <div className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                    <MapPin className="w-3 h-3" /> {h.address}
                  </div>
                </button>
              ))}
            </div>
          </motion.div>
        )}

        {step === 'date' && (
          <SelectDate
            value={date}
            onSelect={(d) => { setDate(d); setStep('time'); }}
            minDate={apptType === 'donation' && eligibility?.nextEligibleDate ? eligibility.nextEligibleDate : undefined}
          />
        )}

        {step === 'time' && (
          <SelectTime
            value={time}
            onSelect={(t2) => { setTime(t2); setStep('summary'); }}
          />
        )}

        {step === 'summary' && hospital && (
          <AppointmentSummary
            hospital={hospital}
            date={date}
            time={time}
            type={apptType}
            notes={notes}
            onNotesChange={setNotes}
            onConfirm={handleConfirm}
          />
        )}

        {step === 'confirm' && confirmed && (
          <AppointmentConfirmation
            appointment={confirmed}
            onDone={() => { setActiveTab('appointments'); onDone?.(); }}
          />
        )}
      </AnimatePresence>
    </div>
  );
};

export default AppointmentFlow;
