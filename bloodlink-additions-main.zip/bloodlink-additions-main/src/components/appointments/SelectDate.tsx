import React from 'react';
import { motion } from 'framer-motion';
import { Calendar } from '../ui/calendar';
import { useLanguage } from '../../context/LanguageContext';

interface Props {
  value: string;
  onSelect: (dateISO: string) => void;
  minDate?: string;
}

const SelectDate: React.FC<Props> = ({ value, onSelect, minDate }) => {
  const { t } = useLanguage();
  const selected = value ? new Date(value) : undefined;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const min = minDate ? new Date(minDate) : today;
  const effectiveMin = min > today ? min : today;

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
      <h2 className="text-2xl font-bold">{t('appt.selectDate')}</h2>
      <div className="bg-card border border-border rounded-3xl p-4 pointer-events-auto">
        <Calendar
          mode="single"
          selected={selected}
          onSelect={(d) => {
            if (d) onSelect(d.toISOString().slice(0, 10));
          }}
          disabled={(d) => d < effectiveMin}
          className="pointer-events-auto"
        />
      </div>
      {minDate && (
        <p className="text-xs text-muted-foreground text-center">Earliest available: {minDate}</p>
      )}
    </motion.div>
  );
};

export default SelectDate;
