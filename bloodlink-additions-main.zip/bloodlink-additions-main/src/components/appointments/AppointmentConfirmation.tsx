import React from 'react';
import { motion } from 'framer-motion';
import { CheckCircle2 } from 'lucide-react';
import { Button } from '../ui/button';
import { useLanguage } from '../../context/LanguageContext';
import type { AppointmentType } from '../../context/ProfileContext';

interface Props {
  appointment: AppointmentType;
  onDone: () => void;
}

const AppointmentConfirmation: React.FC<Props> = ({ appointment, onDone }) => {
  const { t } = useLanguage();
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className="flex flex-col items-center text-center space-y-6 pt-8"
    >
      <div className="w-24 h-24 bg-emerald-500/10 rounded-full flex items-center justify-center">
        <CheckCircle2 className="w-12 h-12 text-emerald-500" />
      </div>
      <div className="space-y-2">
        <h2 className="text-3xl font-bold">{t('appt.confirmed')}</h2>
        <p className="text-muted-foreground">Your appointment is booked.</p>
      </div>
      <div className="w-full bg-card border border-border rounded-3xl p-5 space-y-2 text-left">
        <div className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest">Confirmation code</div>
        <div className="text-2xl font-black text-primary">{appointment.confirmationCode}</div>
        <div className="pt-2 text-sm">
          <div className="font-bold">{appointment.hospitalName}</div>
          <div className="text-muted-foreground">{appointment.date} · {appointment.time}</div>
          <div className="text-muted-foreground">{t(`appt.type.${appointment.type}`)}</div>
        </div>
      </div>
      <Button onClick={onDone} className="w-full h-14 rounded-2xl font-bold text-lg">
        View My Appointments
      </Button>
    </motion.div>
  );
};

export default AppointmentConfirmation;
