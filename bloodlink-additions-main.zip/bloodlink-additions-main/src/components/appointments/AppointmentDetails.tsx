import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, Phone, Navigation, Calendar as CalIcon, Clock, X, RotateCcw, MapPin } from 'lucide-react';
import { Button } from '../ui/button';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '../ui/alert-dialog';
import { useProfile, type AppointmentType } from '../../context/ProfileContext';
import { useLanguage } from '../../context/LanguageContext';
import AppointmentFlow from './AppointmentFlow';
import { toast } from 'sonner';

interface Props {
  appointment: AppointmentType;
  onBack: () => void;
}

const AppointmentDetails: React.FC<Props> = ({ appointment, onBack }) => {
  const { cancelAppointment } = useProfile();
  const { t } = useLanguage();
  const [rescheduling, setRescheduling] = useState(false);

  if (rescheduling) {
    return (
      <AppointmentFlow
        setActiveTab={() => setRescheduling(false)}
        rescheduleFor={appointment}
        onDone={() => setRescheduling(false)}
      />
    );
  }

  const handleCall = () => {
    if (appointment.hospitalPhone) window.location.href = `tel:${appointment.hospitalPhone}`;
  };
  const handleNavigate = () => {
    const q = encodeURIComponent(appointment.hospitalAddress || appointment.hospitalName);
    window.open(`https://maps.google.com/?q=${q}`, '_blank');
  };
  const handleCancel = () => {
    cancelAppointment(appointment.id);
    toast.success('Appointment cancelled');
    onBack();
  };

  const statusColor = appointment.status === 'upcoming' ? 'text-emerald-500 bg-emerald-500/10'
    : appointment.status === 'completed' ? 'text-blue-500 bg-blue-500/10'
    : 'text-red-500 bg-red-500/10';

  return (
    <div className="p-6 space-y-6 max-w-md mx-auto pb-32">
      <button onClick={onBack} className="flex items-center gap-2 text-muted-foreground font-bold">
        <ChevronLeft className="w-5 h-5" /> Back
      </button>

      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
        <div>
          <span className={`inline-block px-3 py-1 rounded-full text-xs font-bold uppercase ${statusColor}`}>{appointment.status}</span>
          <h2 className="text-2xl font-bold mt-3">{t('appt.details')}</h2>
          <p className="text-sm text-muted-foreground">Code: <span className="font-black text-primary">{appointment.confirmationCode}</span></p>
        </div>

        <div className="bg-card border border-border rounded-3xl divide-y divide-border">
          <Row icon={<MapPin className="w-5 h-5 text-blue-500" />} label="Hospital" value={appointment.hospitalName} sub={appointment.hospitalAddress} />
          <Row icon={<CalIcon className="w-5 h-5 text-amber-500" />} label="Date" value={appointment.date} />
          <Row icon={<Clock className="w-5 h-5 text-purple-500" />} label="Time" value={appointment.time} />
          <Row icon={<CalIcon className="w-5 h-5 text-primary" />} label="Type" value={t(`appt.type.${appointment.type}`)} />
          {appointment.notes && <Row icon={<CalIcon className="w-5 h-5 text-muted-foreground" />} label="Notes" value={appointment.notes} />}
        </div>

        <div className="grid grid-cols-2 gap-3">
          <Button variant="outline" onClick={handleCall} className="h-14 rounded-2xl font-bold border-2">
            <Phone className="w-5 h-5 mr-2" /> {t('appt.call')}
          </Button>
          <Button variant="outline" onClick={handleNavigate} className="h-14 rounded-2xl font-bold border-2">
            <Navigation className="w-5 h-5 mr-2" /> {t('appt.navigate')}
          </Button>
        </div>

        {appointment.status === 'upcoming' && (
          <div className="grid grid-cols-2 gap-3">
            <Button onClick={() => setRescheduling(true)} className="h-14 rounded-2xl font-bold">
              <RotateCcw className="w-5 h-5 mr-2" /> {t('appt.reschedule')}
            </Button>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="outline" className="h-14 rounded-2xl font-bold border-2 border-red-500/40 text-red-500 hover:bg-red-500/5 hover:text-red-500">
                  <X className="w-5 h-5 mr-2" /> {t('appt.cancel')}
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Cancel appointment?</AlertDialogTitle>
                  <AlertDialogDescription>This action cannot be undone.</AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Keep</AlertDialogCancel>
                  <AlertDialogAction onClick={handleCancel}>Cancel appointment</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        )}
      </motion.div>
    </div>
  );
};

const Row: React.FC<{ icon: React.ReactNode; label: string; value: string; sub?: string }> = ({ icon, label, value, sub }) => (
  <div className="p-4 flex items-center gap-4">
    <div className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center">{icon}</div>
    <div className="flex-1 min-w-0">
      <div className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest">{label}</div>
      <div className="font-bold truncate">{value}</div>
      {sub && <div className="text-xs text-muted-foreground truncate">{sub}</div>}
    </div>
  </div>
);

export default AppointmentDetails;
