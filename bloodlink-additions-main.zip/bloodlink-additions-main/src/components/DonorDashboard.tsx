import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../context/LanguageContext';
import { useProfile } from '../context/ProfileContext';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Droplet, Heart, MapPin, AlertCircle, Calendar, ArrowRight, Activity, ShieldCheck, Zap, Globe, Users } from 'lucide-react';
import SOSButton from './SOSButton';
import MaternalEmergencyModal from './MaternalEmergencyModal';
import EligibilityChecker from './EligibilityChecker';

interface DonorDashboardProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const LANG_LABEL: Record<string, string> = { en: 'English', ha: 'Hausa', yo: 'Yoruba', ig: 'Igbo', pcm: 'Pidgin' };

const DonorDashboard: React.FC<DonorDashboardProps> = ({ setActiveTab }) => {
  const { t, language } = useLanguage();
  const { profile, totalDonations, upcomingAppointment, computedNextEligibleDate } = useProfile();
  const [showMaternal, setShowMaternal] = useState(false);
  const [showChecker, setShowChecker] = useState(false);

  const eligibility = profile.eligibility;
  const nextEligible = computedNextEligibleDate();

  const donationStreak = profile.donation.history.length; // simple derived

  const eligibilityMeta = eligibility
    ? {
        eligible: { color: 'emerald-500', icon: ShieldCheck, label: t('eligibility.eligible'), emoji: '🟢' },
        screening: { color: 'amber-500', icon: AlertCircle, label: t('eligibility.screening'), emoji: '🟡' },
        ineligible: { color: 'red-500', icon: AlertCircle, label: t('eligibility.ineligible'), emoji: '🔴' },
      }[eligibility.status]
    : null;

  if (showChecker) {
    return <EligibilityChecker onBack={() => setShowChecker(false)} />;
  }

  const stats = [
    { label: t('dash.totalDonations'), value: String(totalDonations), icon: Droplet, color: 'text-primary' },
    { label: t('dash.bloodGroup'), value: profile.health.bloodGroup || '—', icon: Heart, color: 'text-red-500' },
    { label: t('dash.genotype'), value: profile.health.genotype || '—', icon: Activity, color: 'text-emerald-500' },
    { label: t('dash.streak'), value: String(donationStreak), icon: Zap, color: 'text-amber-500' },
  ];

  const missingProfile = !profile.personal.fullName || !profile.health.bloodGroup;

  return (
    <div className="p-6 space-y-6 max-w-md mx-auto">
      {/* Header */}
      <div className="flex justify-between items-start pt-4">
        <div>
          <h2 className="text-muted-foreground font-medium">{t('home.greeting')},</h2>
          <h1 className="text-3xl font-bold">{profile.personal.fullName?.split(' ')[0] || 'Friend'} 👋</h1>
        </div>
        <button onClick={() => setActiveTab('profile')} className="w-12 h-12 rounded-2xl bg-muted overflow-hidden border-2 border-primary/20">
          <img
            src={profile.personal.photo || `https://api.dicebear.com/7.x/avataaars/svg?seed=${profile.personal.fullName || 'User'}`}
            alt="avatar"
            className="w-full h-full object-cover"
          />
        </button>
      </div>

      {missingProfile && (
        <button
          onClick={() => setActiveTab('profile')}
          className="w-full p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-left flex justify-between items-center"
        >
          <span className="font-bold text-amber-700 dark:text-amber-400 text-sm">{t('dash.completeProfile')}</span>
          <ArrowRight className="w-4 h-4 text-amber-500" />
        </button>
      )}

      {/* Eligibility Status Card */}
      <Card className={`p-6 glass-card rounded-[2rem] border-none relative overflow-hidden`}>
        <div className={`absolute top-0 right-0 w-32 h-32 rounded-full -mr-16 -mt-16 blur-3xl bg-${eligibilityMeta?.color ?? 'primary'}/10`} />
        <div className="relative z-10 flex flex-col gap-4">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-xl bg-${eligibilityMeta?.color ?? 'muted'}/10`}>
              {eligibilityMeta ? <eligibilityMeta.icon className={`w-6 h-6 text-${eligibilityMeta.color}`} /> : <ShieldCheck className="w-6 h-6 text-muted-foreground" />}
            </div>
            <div>
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{t('dash.eligibilityStatus')}</p>
              <h3 className="text-xl font-bold">
                {eligibilityMeta ? `${eligibilityMeta.emoji} ${eligibilityMeta.label}` : 'Not assessed'}
              </h3>
            </div>
          </div>

          {eligibility && (
            <>
              <p className="text-sm text-muted-foreground">{eligibility.recommendation}</p>
              <div className="text-xs text-muted-foreground">
                Assessed on {new Date(eligibility.date).toLocaleDateString()}
                {nextEligible && <> · Next eligible: <span className="font-bold text-foreground">{nextEligible}</span></>}
              </div>
            </>
          )}

          <div className="flex gap-2">
            <Button size="sm" onClick={() => setShowChecker(true)} className="rounded-xl font-bold flex-1">
              {eligibility ? t('eligibility.checkAgain') : 'Start Check'}
            </Button>
            <Button size="sm" variant="outline" onClick={() => setActiveTab('booking')} className="rounded-xl font-bold border-2 flex-1">
              Book
            </Button>
          </div>
        </div>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-4">
        {stats.map((stat, i) => (
          <div key={i} className="bg-card p-4 rounded-3xl border border-border flex flex-col gap-2">
            <stat.icon className={`w-5 h-5 ${stat.color}`} />
            <div>
              <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest">{stat.label}</p>
              <p className="text-xl font-bold">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Info rows */}
      <div className="grid grid-cols-2 gap-4">
        <InfoCard icon={<Calendar className="w-5 h-5 text-primary" />} label={t('dash.lastDonation')} value={profile.donation.lastDonationDate || '—'} />
        <InfoCard icon={<Calendar className="w-5 h-5 text-emerald-500" />} label={t('dash.nextEligible')} value={nextEligible ?? '—'} />
        <InfoCard icon={<Users className="w-5 h-5 text-blue-500" />} label={t('dash.availability')} value={Object.values(profile.availability.schedule).filter(Boolean).length + ' days/wk'} />
        <InfoCard icon={<AlertCircle className="w-5 h-5 text-amber-500" />} label={t('dash.emergencyStatus')} value={profile.availability.emergencyDonation ? 'On' : 'Off'} />
      </div>

      {/* Upcoming Appointment */}
      <button
        onClick={() => setActiveTab(upcomingAppointment ? 'appointments' : 'booking')}
        className="w-full p-5 rounded-3xl bg-card border border-border text-left flex justify-between items-center"
      >
        <div>
          <div className="text-[10px] uppercase font-bold text-muted-foreground tracking-widest">{t('dash.upcomingAppt')}</div>
          {upcomingAppointment ? (
            <>
              <div className="font-bold mt-1">{upcomingAppointment.hospitalName}</div>
              <div className="text-xs text-muted-foreground">{upcomingAppointment.date} · {upcomingAppointment.time}</div>
            </>
          ) : (
            <div className="font-bold mt-1 text-muted-foreground">No upcoming — Book now</div>
          )}
        </div>
        <ArrowRight className="w-5 h-5 text-primary" />
      </button>

      {/* Language pill */}
      <div className="flex items-center justify-between p-4 rounded-2xl bg-muted">
        <div className="flex items-center gap-2">
          <Globe className="w-4 h-4 text-blue-500" />
          <span className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Language</span>
        </div>
        <span className="font-bold text-sm">{LANG_LABEL[language]}</span>
      </div>

      {/* Quick Actions */}
      <div className="space-y-4">
        <h3 className="font-bold text-lg px-2">Quick Actions</h3>
        <div className="grid grid-cols-2 gap-4">
          <button
            onClick={() => setActiveTab('requests')}
            className="group bg-primary text-white p-5 rounded-[2rem] text-left flex flex-col justify-between h-44 shadow-lg shadow-primary/30 active:scale-95 transition-all"
          >
            <div className="bg-white/20 w-12 h-12 rounded-2xl flex items-center justify-center">
              <Droplet className="w-6 h-6 fill-white" />
            </div>
            <div>
              <h4 className="font-bold text-lg leading-tight">{t('home.request')}<br />Blood</h4>
              <ArrowRight className="w-5 h-5 mt-2 opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition-all" />
            </div>
          </button>

          <button
            onClick={() => setActiveTab('booking')}
            className="group bg-emerald-500 text-white p-5 rounded-[2rem] text-left flex flex-col justify-between h-44 shadow-lg shadow-emerald-500/30 active:scale-95 transition-all"
          >
            <div className="bg-white/20 w-12 h-12 rounded-2xl flex items-center justify-center">
              <Heart className="w-6 h-6 fill-white" />
            </div>
            <div>
              <h4 className="font-bold text-lg leading-tight">{t('home.donate')}<br />Blood</h4>
              <ArrowRight className="w-5 h-5 mt-2 opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition-all" />
            </div>
          </button>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <button className="bg-card border border-border p-5 rounded-[2rem] text-left flex flex-col justify-between h-44 active:scale-95 transition-all">
            <div className="bg-blue-500/10 w-12 h-12 rounded-2xl flex items-center justify-center">
              <MapPin className="w-6 h-6 text-blue-500" />
            </div>
            <h4 className="font-bold text-lg leading-tight">Nearby<br />Banks</h4>
          </button>

          <button
            onClick={() => setShowMaternal(true)}
            className="bg-card border-2 border-red-500/50 p-5 rounded-[2rem] text-left flex flex-col justify-between h-44 active:scale-95 transition-all relative overflow-hidden"
          >
            <div className="absolute top-2 right-2 flex items-center gap-1 bg-red-500 text-[8px] text-white px-2 py-0.5 rounded-full font-bold uppercase animate-pulse">
              <AlertCircle className="w-2 h-2" /> Urgent
            </div>
            <div className="bg-red-500/10 w-12 h-12 rounded-2xl flex items-center justify-center">
              <Heart className="w-6 h-6 text-red-500" />
            </div>
            <h4 className="font-bold text-lg leading-tight">Maternal<br />Emergency</h4>
          </button>
        </div>
      </div>

      <SOSButton />
      <MaternalEmergencyModal isOpen={showMaternal} onClose={() => setShowMaternal(false)} />
    </div>
  );
};

const InfoCard: React.FC<{ icon: React.ReactNode; label: string; value: string }> = ({ icon, label, value }) => (
  <div className="bg-card p-4 rounded-3xl border border-border flex flex-col gap-2">
    {icon}
    <div>
      <p className="text-[10px] text-muted-foreground uppercase font-bold tracking-widest">{label}</p>
      <p className="text-sm font-bold truncate">{value}</p>
    </div>
  </div>
);

export default DonorDashboard;
