import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useAuth, UserRole } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Droplet, Hospital, Building2, Smartphone, Mail } from 'lucide-react';

const Auth: React.FC = () => {
  const [view, setView] = useState<'role' | 'login'>('role');
  const [selectedRole, setSelectedRole] = useState<UserRole>('donor');
  const { login } = useAuth();
  const { t } = useLanguage();

  const roles: { id: UserRole; name: string; icon: React.ReactNode; desc: string }[] = [
    { 
      id: 'donor', 
      name: t('role.donor'), 
      icon: <Droplet className="w-6 h-6 text-primary" />,
      desc: 'Donate blood and save lives in your community.'
    },
    { 
      id: 'hospital', 
      name: t('role.hospital'), 
      icon: <Hospital className="w-6 h-6 text-blue-500" />,
      desc: 'Request blood and manage emergency donor matches.'
    },
    { 
      id: 'bank', 
      name: t('role.bank'), 
      icon: <Building2 className="w-6 h-6 text-emerald-500" />,
      desc: 'Manage blood inventory and supply requests.'
    },
  ];

  if (view === 'role') {
    return (
      <div className="min-h-screen p-6 flex flex-col justify-center bg-background">
        <div className="mb-10 text-center">
          <div className="w-20 h-20 bg-primary/10 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-inner">
            <Droplet className="w-10 h-10 text-primary fill-primary/20" />
          </div>
          <h1 className="text-3xl font-bold mb-2">Welcome to BloodLink AI</h1>
          <p className="text-muted-foreground">Select how you want to use the platform</p>
        </div>

        <div className="space-y-4 mb-10">
          {roles.map((r) => (
            <button
              key={r.id}
              onClick={() => setSelectedRole(r.id)}
              className={`w-full p-5 rounded-3xl text-left border-2 transition-all flex gap-5 items-start ${
                selectedRole === r.id
                  ? 'border-primary bg-primary/5 shadow-md ring-1 ring-primary'
                  : 'border-border bg-card'
              }`}
            >
              <div className={`p-3 rounded-2xl ${
                selectedRole === r.id ? 'bg-primary/20' : 'bg-muted'
              }`}>
                {r.icon}
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-lg">{r.name}</h3>
                <p className="text-sm text-muted-foreground leading-snug">{r.desc}</p>
              </div>
            </button>
          ))}
        </div>

        <Button 
          onClick={() => setView('login')}
          className="h-14 rounded-2xl text-lg font-bold shadow-xl shadow-primary/20"
        >
          Continue as {roles.find(r => r.id === selectedRole)?.name}
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-6 flex flex-col bg-background">
      <div className="mt-12 mb-10">
        <h1 className="text-3xl font-bold mb-2">Login</h1>
        <p className="text-muted-foreground">Login to your {selectedRole} account</p>
      </div>

      <div className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="email">Email or Phone Number</Label>
          <div className="relative">
            <Input id="email" placeholder="musa@example.com" className="h-14 pl-4 rounded-2xl bg-muted/50 border-none focus-visible:ring-primary" />
          </div>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="password">Password</Label>
          <Input id="password" type="password" placeholder="••••••••" className="h-14 pl-4 rounded-2xl bg-muted/50 border-none focus-visible:ring-primary" />
        </div>

        <Button 
          onClick={() => login(selectedRole)}
          className="w-full h-14 rounded-2xl text-lg font-bold shadow-xl shadow-primary/20 mt-4"
        >
          Sign In
        </Button>

        <div className="relative my-8">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-border"></div>
          </div>
          <div className="relative flex justify-center text-xs uppercase">
            <span className="bg-background px-4 text-muted-foreground font-medium">Or continue with</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <Button variant="outline" className="h-14 rounded-2xl border-2 flex gap-3 hover:bg-primary/5">
            <Smartphone className="w-5 h-5" /> Phone
          </Button>
          <Button variant="outline" className="h-14 rounded-2xl border-2 flex gap-3 hover:bg-primary/5">
            <Mail className="w-5 h-5" /> Google
          </Button>
        </div>

        <p className="text-center text-sm text-muted-foreground mt-8">
          Don't have an account? <span className="text-primary font-bold cursor-pointer">Sign Up</span>
        </p>
      </div>
    </div>
  );
};

export default Auth;
