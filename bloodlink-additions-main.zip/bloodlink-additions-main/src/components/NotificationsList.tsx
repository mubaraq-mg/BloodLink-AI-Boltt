import React from 'react';
import { Card } from './ui/card';
import { Bell, CheckCircle2, AlertCircle, Droplet, Heart } from 'lucide-react';

const NotificationsList: React.FC = () => {
  const notifications = [
    { id: '1', title: 'Emergency Request', body: 'Urgent need for O+ blood at City Hospital.', time: '2m ago', type: 'emergency' },
    { id: '2', title: 'Donation Reminder', body: 'You are now eligible to donate blood again!', time: '1h ago', type: 'reminder' },
    { id: '3', title: 'Thank You', body: 'Your recent donation helped save a life.', time: 'Yesterday', type: 'success' },
  ];

  return (
    <div className="p-6 space-y-6 max-w-md mx-auto">
      <div className="flex justify-between items-center pt-4">
        <h1 className="text-3xl font-bold">Alerts</h1>
        <span className="px-3 py-1 bg-primary text-white text-[10px] font-bold rounded-full">3 NEW</span>
      </div>

      <div className="space-y-3">
        {notifications.map((n) => (
          <div key={n.id} className="p-4 bg-card border border-border rounded-3xl flex gap-4 items-start relative overflow-hidden group">
            <div className={`p-3 rounded-2xl ${
              n.type === 'emergency' ? 'bg-red-500/10' : 
              n.type === 'reminder' ? 'bg-amber-500/10' : 'bg-emerald-500/10'
            }`}>
              {n.type === 'emergency' ? <AlertCircle className="w-5 h-5 text-red-500" /> : 
               n.type === 'reminder' ? <Droplet className="w-5 h-5 text-amber-500" /> : 
               <CheckCircle2 className="w-5 h-5 text-emerald-500" />}
            </div>
            <div className="flex-1 space-y-1">
              <div className="flex justify-between items-start">
                <h4 className="font-bold text-sm">{n.title}</h4>
                <span className="text-[10px] text-muted-foreground font-bold uppercase">{n.time}</span>
              </div>
              <p className="text-xs text-muted-foreground leading-relaxed">{n.body}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default NotificationsList;
