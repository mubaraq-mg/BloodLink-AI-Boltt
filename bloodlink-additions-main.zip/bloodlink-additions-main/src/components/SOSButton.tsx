import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertTriangle, X, ChevronRight, MapPin, Clock, CheckCircle2 } from 'lucide-react';
import { Button } from './ui/button';
import { toast } from 'sonner';

const SOSButton: React.FC = () => {
  const [isConfirming, setIsConfirming] = useState(false);
  const [status, setStatus] = useState<'idle' | 'notifying' | 'sent'>('idle');

  const handleSOS = () => {
    setIsConfirming(true);
  };

  const confirmSOS = () => {
    setStatus('notifying');
    setTimeout(() => {
      setStatus('sent');
      toast.success('Emergency alert broadcasted to nearby compatible donors!');
    }, 2500);
  };

  return (
    <>
      <div className="fixed bottom-32 right-6 z-40">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={handleSOS}
          className="w-16 h-16 bg-primary rounded-3xl flex items-center justify-center shadow-2xl shadow-primary/40 border-4 border-white dark:border-zinc-900"
        >
          <AlertTriangle className="w-8 h-8 text-white animate-pulse" />
        </motion.button>
      </div>

      <AnimatePresence>
        {isConfirming && (
          <div className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsConfirming(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="relative w-full max-w-md bg-card rounded-[2.5rem] p-8 space-y-8 shadow-2xl overflow-hidden"
            >
              {status === 'idle' && (
                <>
                  <div className="w-20 h-20 bg-primary/10 rounded-3xl flex items-center justify-center mx-auto mb-6">
                    <AlertTriangle className="w-10 h-10 text-primary" />
                  </div>
                  <div className="text-center space-y-2">
                    <h2 className="text-3xl font-bold">Confirm Emergency</h2>
                    <p className="text-muted-foreground">This will immediately notify all compatible donors within 5km of your location.</p>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <Button 
                      variant="outline" 
                      onClick={() => setIsConfirming(false)}
                      className="h-14 rounded-2xl text-lg font-bold border-2"
                    >
                      Cancel
                    </Button>
                    <Button 
                      onClick={confirmSOS}
                      className="h-14 rounded-2xl text-lg font-bold bg-primary shadow-lg shadow-primary/20"
                    >
                      Yes, Alert Now
                    </Button>
                  </div>
                </>
              )}

              {status === 'notifying' && (
                <div className="py-12 flex flex-col items-center text-center space-y-6">
                  <div className="relative">
                    <div className="w-24 h-24 border-4 border-primary/20 rounded-full" />
                    <motion.div 
                      animate={{ rotate: 360 }}
                      transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
                      className="absolute inset-0 border-4 border-t-primary rounded-full"
                    />
                    <AlertTriangle className="absolute inset-0 m-auto w-10 h-10 text-primary" />
                  </div>
                  <div className="space-y-2">
                    <h2 className="text-2xl font-bold">Scanning for Donors</h2>
                    <p className="text-muted-foreground">AI is matching compatible donors nearby...</p>
                  </div>
                </div>
              )}

              {status === 'sent' && (
                <div className="py-8 space-y-8">
                  <div className="flex flex-col items-center text-center space-y-4">
                    <div className="w-20 h-20 bg-emerald-500/10 rounded-full flex items-center justify-center">
                      <CheckCircle2 className="w-10 h-10 text-emerald-500" />
                    </div>
                    <h2 className="text-2xl font-bold">Alert Broadcasted</h2>
                    <p className="text-muted-foreground">4 compatible donors found nearby. Waiting for acceptance.</p>
                  </div>

                  <div className="space-y-3">
                    {[
                      { name: 'Dr. John', dist: '1.2km', time: '5m' },
                      { name: 'Aisha K.', dist: '2.5km', time: '12m' },
                    ].map((donor, i) => (
                      <div key={i} className="flex items-center justify-between p-4 bg-muted/50 rounded-2xl">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center font-bold text-primary">
                            {donor.name[0]}
                          </div>
                          <div>
                            <p className="font-bold">{donor.name}</p>
                            <p className="text-xs text-muted-foreground flex items-center gap-1">
                              <MapPin className="w-3 h-3" /> {donor.dist}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-bold text-primary flex items-center gap-1 justify-end">
                            <Clock className="w-3 h-3" /> {donor.time}
                          </p>
                          <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-wider">Estimated</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  <Button 
                    onClick={() => setIsConfirming(false)}
                    className="w-full h-14 rounded-2xl text-lg font-bold"
                  >
                    View Status
                  </Button>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};

export default SOSButton;
