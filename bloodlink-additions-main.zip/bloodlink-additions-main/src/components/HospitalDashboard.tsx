import React, { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Plus, Search, MapPin, Filter, MoreHorizontal, Droplet, ArrowUpRight, ShieldCheck, Building2 } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface HospitalDashboardProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const HospitalDashboard: React.FC<HospitalDashboardProps> = ({ activeTab, setActiveTab }) => {
  const { t } = useLanguage();

  return (
    <div className="p-6 space-y-8 max-w-md mx-auto">
      <div className="flex justify-between items-start pt-4">
        <div>
          <h2 className="text-muted-foreground font-medium">St. Nicholas Hospital</h2>
          <h1 className="text-3xl font-bold">Dashboard</h1>
        </div>
        <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 flex items-center justify-center border-2 border-emerald-500/20">
          <ShieldCheck className="w-6 h-6 text-emerald-500" />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Button className="h-32 rounded-[2rem] flex flex-col gap-2 items-center justify-center bg-primary shadow-lg shadow-primary/20">
          <Plus className="w-8 h-8" />
          <span className="font-bold">New Request</span>
        </Button>
        <Button variant="outline" className="h-32 rounded-[2rem] flex flex-col gap-2 items-center justify-center border-2 border-primary/20 hover:bg-primary/5">
          <Search className="w-8 h-8 text-primary" />
          <span className="font-bold text-primary">Find Donors</span>
        </Button>
      </div>

      <div className="space-y-4">
        <div className="flex justify-between items-center px-2">
          <h3 className="font-bold text-xl">Active Requests</h3>
          <button className="text-primary font-bold text-sm">See All</button>
        </div>

        {[
          { patient: 'Zainab B.', type: 'O-', units: '2 Units', status: 'Urgent', matching: 4 },
          { patient: 'Obinna K.', type: 'B+', units: '1 Unit', status: 'Normal', matching: 12 },
        ].map((req, i) => (
          <Card key={i} className="p-5 rounded-3xl border border-border bg-card relative overflow-hidden group hover:shadow-lg transition-all">
            <div className="flex justify-between items-start mb-4">
              <div className="flex gap-4">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black text-xl ${
                  req.status === 'Urgent' ? 'bg-primary text-white' : 'bg-muted text-muted-foreground'
                }`}>
                  {req.type}
                </div>
                <div>
                  <h4 className="font-bold text-lg">{req.patient}</h4>
                  <p className="text-xs text-muted-foreground font-medium uppercase tracking-widest">{req.units}</p>
                </div>
              </div>
              <div className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest ${
                req.status === 'Urgent' ? 'bg-red-500 text-white animate-pulse' : 'bg-blue-500/10 text-blue-500'
              }`}>
                {req.status}
              </div>
            </div>
            
            <div className="flex justify-between items-center pt-4 border-t border-border/50">
              <div className="flex items-center gap-2">
                <div className="flex -space-x-2">
                  {[1, 2, 3].map(n => (
                    <div key={n} className="w-6 h-6 rounded-full border-2 border-background bg-muted overflow-hidden">
                      <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${n + i * 10}`} alt="donor" />
                    </div>
                  ))}
                </div>
                <span className="text-xs font-bold text-muted-foreground">+{req.matching} matches</span>
              </div>
              <Button size="sm" variant="ghost" className="rounded-xl p-2 group-hover:bg-primary/10 group-hover:text-primary transition-all">
                <ArrowUpRight className="w-5 h-5" />
              </Button>
            </div>
          </Card>
        ))}
      </div>

      <div className="space-y-4">
        <h3 className="font-bold text-xl px-2">Nearby Banks</h3>
        <div className="flex gap-4 overflow-x-auto pb-4 no-scrollbar -mx-6 px-6">
          {[
            { name: 'Red Cross Bank', dist: '0.8km', status: 'Open' },
            { name: 'City Blood Bank', dist: '2.3km', status: 'Closing Soon' },
            { name: 'LifeSafe Center', dist: '4.5km', status: 'Open' },
          ].map((bank, i) => (
            <div key={i} className="min-w-[200px] bg-card p-5 rounded-3xl border border-border space-y-3">
              <div className="w-10 h-10 bg-muted rounded-2xl flex items-center justify-center">
                <Building2 className="w-5 h-5 text-muted-foreground" />
              </div>
              <div>
                <h4 className="font-bold">{bank.name}</h4>
                <p className="text-xs text-muted-foreground flex items-center gap-1">
                  <MapPin className="w-3 h-3" /> {bank.dist}
                </p>
              </div>
              <div className="flex justify-between items-center pt-2">
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  bank.status === 'Open' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-amber-500/10 text-amber-500'
                }`}>{bank.status}</span>
                <Button size="icon" variant="ghost" className="h-8 w-8 rounded-full">
                  <ArrowUpRight className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
export default HospitalDashboard;
