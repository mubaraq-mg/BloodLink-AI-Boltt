import React from 'react';
import { Card } from './ui/card';
import { Droplet, MapPin, Clock, ArrowRight, Filter } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const RequestsList: React.FC = () => {
  const { role } = useAuth();

  const requests = [
    { id: '1', patient: 'Aisha Musa', type: 'O+', units: '2', location: 'City General Hospital', urgency: 'Critical', time: '10m ago' },
    { id: '2', patient: 'Samuel Oko', type: 'B-', units: '1', location: 'LifeCare Clinic', urgency: 'Urgent', time: '25m ago' },
    { id: '3', patient: 'Chioma Ade', type: 'A+', units: '3', location: "St. Mary's Center", urgency: 'Normal', time: '1h ago' },
  ];

  return (
    <div className="p-6 space-y-6 max-w-md mx-auto">
      <div className="flex justify-between items-center pt-4">
        <h1 className="text-3xl font-bold">Requests</h1>
        <button className="w-10 h-10 bg-muted rounded-xl flex items-center justify-center">
          <Filter className="w-5 h-5 text-muted-foreground" />
        </button>
      </div>

      <div className="space-y-4">
        {requests.map((req) => (
          <Card key={req.id} className="p-5 rounded-3xl border border-border bg-card hover:shadow-lg transition-all group">
            <div className="flex justify-between items-start mb-4">
              <div className="flex gap-4">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black text-xl bg-primary/10 text-primary`}>
                  {req.type}
                </div>
                <div>
                  <h4 className="font-bold text-lg">{req.patient}</h4>
                  <p className="text-xs text-muted-foreground font-medium flex items-center gap-1">
                    <Clock className="w-3 h-3" /> {req.time}
                  </p>
                </div>
              </div>
              <div className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest ${
                req.urgency === 'Critical' ? 'bg-red-500 text-white animate-pulse' : 
                req.urgency === 'Urgent' ? 'bg-amber-500 text-white' : 'bg-blue-500 text-white'
              }`}>
                {req.urgency}
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <MapPin className="w-4 h-4 text-primary" />
                <span className="truncate">{req.location}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Droplet className="w-4 h-4 text-primary" />
                <span>{req.units} Units Required</span>
              </div>
            </div>

            <button className="w-full mt-5 h-12 rounded-2xl bg-muted group-hover:bg-primary group-hover:text-white transition-all font-bold text-sm flex items-center justify-center gap-2">
              View Details <ArrowRight className="w-4 h-4" />
            </button>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default RequestsList;
